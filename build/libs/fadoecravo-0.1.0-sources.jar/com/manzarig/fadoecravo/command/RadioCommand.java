package com.manzarig.fadoecravo.command;

import com.manzarig.fadoecravo.FadoECravo;
import com.manzarig.fadoecravo.broadcast.BreakingNewsState;
import com.manzarig.fadoecravo.broadcast.StationIds;
import com.manzarig.fadoecravo.net.BreakingNewsPayload;
import com.manzarig.fadoecravo.net.ModNetworking;
import com.mojang.brigadier.arguments.StringArgumentType;
import com.mojang.brigadier.builder.LiteralArgumentBuilder;
import com.mojang.brigadier.context.CommandContext;
import com.mojang.brigadier.exceptions.CommandSyntaxException;
import com.mojang.brigadier.exceptions.DynamicCommandExceptionType;
import net.fabricmc.fabric.api.command.v2.CommandRegistrationCallback;
import net.minecraft.class_2168;
import net.minecraft.class_2170;
import net.minecraft.class_2172;
import net.minecraft.class_2561;
import net.minecraft.class_3218;
import net.minecraft.server.MinecraftServer;

/**
 * {@code /fadoecravo breaking <station>} puts a breaking news bulletin on the air on a station and
 * {@code /fadoecravo breaking clear} takes it off. Both need permission level 2.
 *
 * <p>The command only records the bulletin and tells the clients; it is the client that interrupts
 * the programme of the radios tuned to the station.
 */
public final class RadioCommand {
	private static final String STATION = "station";

	private static final DynamicCommandExceptionType UNKNOWN_STATION = new DynamicCommandExceptionType(
			id -> class_2561.method_43469("command.fadoecravo.breaking.unknown_station", id));

	private RadioCommand() {
	}

	public static void register() {
		CommandRegistrationCallback.EVENT.register((dispatcher, registryAccess, environment) -> dispatcher.register(build()));
	}

	/** The command tree, separate from the registration so it can be built without the callback. */
	static LiteralArgumentBuilder<class_2168> build() {
		return class_2170.method_9247("fadoecravo")
				.requires(source -> source.method_9259(class_2170.field_31839))
				.then(class_2170.method_9247("breaking")
						.then(class_2170.method_9247("clear")
								.executes(RadioCommand::clear))
						.then(class_2170.method_9244(STATION, StringArgumentType.word())
								.suggests((context, builder) -> class_2172.method_9265(StationIds.builtIn(), builder))
								.executes(RadioCommand::breaking)));
	}

	private static int breaking(CommandContext<class_2168> context) throws CommandSyntaxException {
		String station = StringArgumentType.getString(context, STATION);
		if (!StationIds.isBuiltIn(station)) {
			throw UNKNOWN_STATION.create(station);
		}
		class_2168 source = context.getSource();
		MinecraftServer server = source.method_9211();
		class_3218 overworld = server.method_30002();

		BreakingNewsPayload news = BreakingNewsState.get(server)
				.start(station, overworld.method_8510(), overworld.method_8409().method_43055());
		ModNetworking.broadcast(server, news);

		source.method_9226(() -> class_2561.method_43469("command.fadoecravo.breaking.success",
				class_2561.method_43471("station." + FadoECravo.MOD_ID + "." + station)), true);
		return 1;
	}

	private static int clear(CommandContext<class_2168> context) {
		class_2168 source = context.getSource();
		MinecraftServer server = source.method_9211();

		BreakingNewsState.get(server).clear();
		ModNetworking.broadcast(server, BreakingNewsPayload.CLEARED);

		source.method_9226(() -> class_2561.method_43471("command.fadoecravo.breaking.cleared"), true);
		return 1;
	}
}
