package com.manzarig.fadoecravo;

import java.util.function.Consumer;
import net.minecraft.class_2338;

/**
 * Lets the radio block, which lives in common code, open a screen that only exists on the client.
 *
 * <p>{@code RadioBlock} must not name a client class because a dedicated server cannot load it.
 * It calls {@link #openScreen(class_2338)} instead, which does nothing until the client has set
 * {@link #screenOpener}, so on a dedicated server (or before the client has started) the call is
 * harmless.
 */
public final class RadioClientBridge {
	private static final Consumer<class_2338> NO_OP = pos -> {
	};

	/**
	 * Opens the radio screen for the radio at the given position. The client replaces it when it
	 * starts, either by assigning this field or through {@link #setScreenOpener(Consumer)}.
	 */
	public static volatile Consumer<class_2338> screenOpener = NO_OP;

	private RadioClientBridge() {
	}

	/** Opens the radio screen for the radio at {@code pos}; does nothing without a client. */
	public static void openScreen(class_2338 pos) {
		Consumer<class_2338> opener = screenOpener;
		if (opener != null) {
			opener.accept(pos);
		}
	}

	/** Sets {@link #screenOpener}; {@code null} restores the default, which does nothing. */
	public static void setScreenOpener(Consumer<class_2338> opener) {
		screenOpener = opener == null ? NO_OP : opener;
	}
}
