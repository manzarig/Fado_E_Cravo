package com.manzarig.fadoecravo.client.audio;

import net.minecraft.class_1101;
import net.minecraft.class_1113;
import net.minecraft.class_2338;
import net.minecraft.class_3414;
import net.minecraft.class_3419;

/**
 * A seamless loop that plays from a radio: the static between stations, or the faint carrier hiss of
 * a station that is on the dial but has nothing on the air. It is the looping counterpart of
 * {@link RadioSoundInstance} and has the same volume API, so a radio can mix the two by setting
 * targets and letting the volumes glide.
 *
 * <p>The sound engine loops it by itself ({@code sounds.json} has these entries with
 * {@code "stream": false}, so the whole OGG sits in a buffer) and calls {@link #method_16896()} on the client
 * main thread. Keep the volume at 1 or below: the range comes from {@code attenuation_distance} in
 * sounds.json, and only a volume above 1 would widen it.
 */
public class StaticSoundInstance extends class_1101 {
	private float targetVolume;
	private boolean stopWhenSilent;

	/**
	 * @param sound  the loop to play, normally {@code ModSounds.STATIC_LOOP} or {@code ModSounds.CARRIER_HISS}
	 * @param pos    block the sound comes from; it plays at the centre of the block
	 * @param volume starting volume, which is also the first fade target
	 */
	public StaticSoundInstance(class_3414 sound, class_2338 pos, float volume) {
		super(sound, class_3419.field_15247, class_1113.method_43221());
		this.field_5442 = Math.max(0.0f, volume);
		this.targetVolume = this.field_5442;
		this.field_5446 = true;
		this.field_5440 = class_1113.class_1114.field_5476;
		this.field_5439 = pos.method_10263() + 0.5;
		this.field_5450 = pos.method_10264() + 0.5;
		this.field_5449 = pos.method_10260() + 0.5;
	}

	/** Volume the fade has reached so far; the plain value this class manages, as in {@link RadioSoundInstance#getCurrentVolume()}. */
	public float getCurrentVolume() {
		return field_5442;
	}

	/** Volume the fade is heading for. */
	public float getTargetVolume() {
		return targetVolume;
	}

	/** Fades to {@code volume} (not below 0) by {@link RadioSoundInstance#FADE_STEP} per tick and cancels a pending {@link #fadeOutAndStop()}. */
	public void setTargetVolume(float volume) {
		this.targetVolume = Math.max(0.0f, volume);
		this.stopWhenSilent = false;
	}

	/** Fades to silence, then stops the sound. */
	public void fadeOutAndStop() {
		this.targetVolume = 0.0f;
		this.stopWhenSilent = true;
	}

	@Override
	public void method_16896() {
		if (field_5442 < targetVolume) {
			field_5442 = Math.min(field_5442 + RadioSoundInstance.FADE_STEP, targetVolume);
		} else if (field_5442 > targetVolume) {
			field_5442 = Math.max(field_5442 - RadioSoundInstance.FADE_STEP, targetVolume);
		}
		if (stopWhenSilent && field_5442 <= 0.0f) {
			method_24876();
		}
	}

	/**
	 * The sound engine skips an instance whose volume is 0 when it is started unless this is true. A
	 * radio keeps its static running at volume 0 while a station comes in clearly, and fades it in
	 * again when the dial moves away.
	 */
	@Override
	public boolean method_4785() {
		return true;
	}
}
