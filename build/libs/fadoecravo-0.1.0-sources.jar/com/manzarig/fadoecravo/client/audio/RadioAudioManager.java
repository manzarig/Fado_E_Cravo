package com.manzarig.fadoecravo.client.audio;

import com.manzarig.fadoecravo.block.RadioBlock;
import com.manzarig.fadoecravo.block.entity.RadioBlockEntity;
import com.manzarig.fadoecravo.broadcast.ClipInfo;
import com.manzarig.fadoecravo.broadcast.StationDefinition;
import com.manzarig.fadoecravo.client.broadcast.ClientBreakingNews;
import com.manzarig.fadoecravo.client.station.StationRegistry;
import com.manzarig.fadoecravo.registry.ModSounds;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientBlockEntityEvents;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.networking.v1.ClientPlayConnectionEvents;
import net.minecraft.class_1113;
import net.minecraft.class_1144;
import net.minecraft.class_2338;
import net.minecraft.class_243;
import net.minecraft.class_2680;
import net.minecraft.class_2960;
import net.minecraft.class_310;
import net.minecraft.class_3419;
import net.minecraft.class_4184;
import net.minecraft.class_638;

/**
 * Plays the sound of every switched-on radio near the player: the station's programme, the static
 * between stations and the hiss of a carrier with nothing on it.
 *
 * <p><b>How the sound stays in sync.</b> There is no server-side playback and no message from the
 * server for the programme. A station's file says what it plays in each part of the day, and
 * {@code BroadcastSchedule} turns the world's day time into "this clip, this many seconds in". Every
 * client does that calculation on the same world time, so everyone hears the same programme, and a
 * radio switched on or walked up to is simply started part-way through the clip, with
 * {@link RadioSoundInstance}. Breaking news is the one thing the server announces
 * ({@link ClientBreakingNews}); it also has a calculated position, from the game time it began at.
 * {@link RadioChannel} holds the details of following the schedule.
 *
 * <p><b>Which radios.</b> Radios are tracked as their block entities load and unload. Each tick the
 * manager takes those within {@value RadioSelection#RANGE_BLOCKS} blocks of the camera whose block
 * state has {@code ON}, keeps the {@value RadioSelection#MAX_RADIOS} nearest and hands each a
 * {@link RadioChannel}. A radio that stops qualifying (switched off, too far, unloaded, another
 * level) fades out over half a second; leaving the world stops everything at once. Nothing is
 * played or advanced while the game is paused in a single-player world.
 *
 * <p>Everything runs on the client main thread. Wire it up with one call to {@link #register()} from
 * the client initializer.
 */
public final class RadioAudioManager {
	private static final double RANGE_SQR = RadioSelection.RANGE_BLOCKS * RadioSelection.RANGE_BLOCKS;

	/** Every radio block entity the client has loaded, by position. */
	private static final Map<class_2338, RadioBlockEntity> RADIOS = new HashMap<>();
	/** The channels of the radios being played, by position. */
	private static final Map<class_2338, RadioChannel> CHANNELS = new LinkedHashMap<>();
	private static final DayClockWatch CLOCK = new DayClockWatch();
	/** The real sound engine, behind the interface the channels use. */
	private static final RadioChannel.Output ENGINE = new RadioChannel.Output() {
		@Override
		public void play(class_1113 sound) {
			class_310.method_1551().method_1483().method_4873(sound);
		}

		@Override
		public boolean isActive(class_1113 sound) {
			return class_310.method_1551().method_1483().method_4877(sound);
		}

		@Override
		public void stop(class_1113 sound) {
			class_310.method_1551().method_1483().method_4870(sound);
		}
	};

	private static long tick;
	private static class_638 level;
	/** The radios played in the last tick, nearest first. */
	private static List<class_2338> selected = List.of();

	private RadioAudioManager() {
	}

	/**
	 * Registers everything: the block entity load and unload events, the per-tick update, the
	 * breaking-news receiver ({@link ClientBreakingNews#register()}) and the clean-up on disconnect.
	 * Call once from the client initializer.
	 */
	public static void register() {
		ClientBreakingNews.register();
		ClientBlockEntityEvents.BLOCK_ENTITY_LOAD.register((blockEntity, world) -> {
			if (blockEntity instanceof RadioBlockEntity radio) {
				RADIOS.put(radio.method_11016().method_10062(), radio);
			}
		});
		ClientBlockEntityEvents.BLOCK_ENTITY_UNLOAD.register((blockEntity, world) -> {
			if (blockEntity instanceof RadioBlockEntity radio) {
				onUnload(radio);
			}
		});
		ClientTickEvents.END_CLIENT_TICK.register(RadioAudioManager::onClientTick);
		ClientPlayConnectionEvents.DISCONNECT.register((handler, client) -> stopEverything());
	}

	/**
	 * What each radio being played is doing, nearest first. Empty before the first tick or when no
	 * radio qualifies. Call on the client thread.
	 */
	public static List<RadioDebugState> snapshot() {
		List<RadioDebugState> states = new ArrayList<>();
		for (class_2338 pos : selected) {
			RadioChannel channel = CHANNELS.get(pos);
			if (channel != null) {
				states.add(channel.debugState());
			}
		}
		return List.copyOf(states);
	}

	private static void onUnload(RadioBlockEntity radio) {
		class_2338 pos = radio.method_11016();
		// A replacement block entity is loaded before the old one is unloaded; keep the newer one.
		if (RADIOS.remove(pos, radio)) {
			RadioChannel channel = CHANNELS.remove(pos);
			if (channel != null) {
				channel.release();
			}
		}
	}

	private static void onClientTick(class_310 minecraft) {
		class_638 currentLevel = minecraft.field_1687;
		if (currentLevel == null) {
			if (level != null || !CHANNELS.isEmpty() || !RADIOS.isEmpty()) {
				stopEverything(); // not every tick on the title screen
			}
			return;
		}
		if (minecraft.field_1724 == null || minecraft.method_1493()) {
			return;
		}
		if (currentLevel != level) {
			// Another dimension: the old level's radios are gone (Fabric unloads their block entities), so
			// let whatever is still sounding fade out and start from nothing.
			releaseChannels();
			CLOCK.reset();
			level = currentLevel;
		}
		tick++;
		long dayTime = currentLevel.method_8532();
		CLOCK.observe(dayTime);

		class_243 ear = listenerPosition(minecraft);
		List<class_2338> candidates = new ArrayList<>();
		Iterator<RadioBlockEntity> radios = RADIOS.values().iterator();
		while (radios.hasNext()) {
			RadioBlockEntity radio = radios.next();
			if (radio.method_11015() || radio.method_10997() != currentLevel) {
				radios.remove();
				continue;
			}
			class_2338 pos = radio.method_11016();
			if (distanceSqr(pos, ear) <= RANGE_SQR && isSwitchedOn(currentLevel, pos)) {
				candidates.add(pos);
			}
		}
		selected = RadioSelection.nearest(candidates, CHANNELS::containsKey, ear.field_1352, ear.field_1351, ear.field_1350,
			RadioSelection.MAX_RADIOS, RadioSelection.RANGE_BLOCKS);

		CHANNELS.entrySet().removeIf(entry -> {
			if (selected.contains(entry.getKey())) {
				return false;
			}
			entry.getValue().release();
			return true;
		});

		RadioChannel.Frame frame = new RadioChannel.Frame(tick, dayTime, currentLevel.method_8510(), CLOCK.isFrozen(),
			StationRegistry.all(), ClientBreakingNews.current());
		for (class_2338 pos : selected) {
			RadioChannel channel = CHANNELS.computeIfAbsent(pos,
				key -> new RadioChannel(key, ENGINE, ModSounds.STATIC_LOOP, ModSounds.CARRIER_HISS));
			channel.tick(frame, RADIOS.get(pos).getFrequencyKhz());
		}
	}

	private static boolean isSwitchedOn(class_638 world, class_2338 pos) {
		class_2680 state = world.method_8320(pos);
		return state.method_28498(RadioBlock.ON) && state.method_11654(RadioBlock.ON);
	}

	private static double distanceSqr(class_2338 pos, class_243 point) {
		double dx = pos.method_10263() + 0.5 - point.field_1352;
		double dy = pos.method_10264() + 0.5 - point.field_1351;
		double dz = pos.method_10260() + 0.5 - point.field_1350;
		return dx * dx + dy * dy + dz * dz;
	}

	/** Where the sound engine puts the listener: the camera, which is not the player in third person. */
	private static class_243 listenerPosition(class_310 minecraft) {
		class_4184 camera = minecraft.field_1773.method_19418();
		return camera.method_19332() ? camera.method_19326() : minecraft.field_1724.method_33571();
	}

	/** Fades every channel's sounds out and forgets the channels. */
	private static void releaseChannels() {
		for (RadioChannel channel : CHANNELS.values()) {
			channel.release();
		}
		CHANNELS.clear();
		selected = List.of();
	}

	/** Stops every channel's sounds on the spot and forgets the channels. */
	private static void stopChannels() {
		for (RadioChannel channel : CHANNELS.values()) {
			channel.stopNow();
		}
		CHANNELS.clear();
		selected = List.of();
	}

	/**
	 * Stops every sound of the mod's radios on the spot, including those that are fading out and so
	 * belong to no channel any more. The sound engine finds them by the id of their sound: the two
	 * loops and the clips of every station.
	 */
	private static void silenceAll() {
		class_1144 sounds = class_310.method_1551().method_1483();
		Set<class_2960> ids = new HashSet<>();
		ids.add(ModSounds.STATIC_LOOP.method_14833());
		ids.add(ModSounds.CARRIER_HISS.method_14833());
		for (StationDefinition station : StationRegistry.all()) {
			for (ClipInfo clip : station.clips().values()) {
				ids.add(clip.sound());
			}
		}
		for (class_2960 id : ids) {
			sounds.method_4875(id, class_3419.field_15247);
		}
	}

	/** Leaving the world: stop all sound and forget the radios and the level. */
	private static void stopEverything() {
		stopChannels();
		silenceAll();
		RADIOS.clear();
		CLOCK.reset();
		level = null;
	}
}
