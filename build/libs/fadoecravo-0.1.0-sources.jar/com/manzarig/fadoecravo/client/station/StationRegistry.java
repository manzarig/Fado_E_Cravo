package com.manzarig.fadoecravo.client.station;

import com.google.gson.JsonElement;
import com.google.gson.JsonParser;
import com.manzarig.fadoecravo.FadoECravo;
import com.manzarig.fadoecravo.broadcast.StationDefinition;
import java.io.Reader;
import java.util.Collection;
import java.util.Collections;
import java.util.Comparator;
import java.util.LinkedHashMap;
import java.util.Map;
import java.util.Optional;
import net.fabricmc.fabric.api.resource.ResourceManagerHelper;
import net.fabricmc.fabric.api.resource.SimpleSynchronousResourceReloadListener;
import net.minecraft.class_2960;
import net.minecraft.class_3264;
import net.minecraft.class_3298;
import net.minecraft.class_3300;

/**
 * The stations the client knows about, loaded from {@code assets/<namespace>/stations/*.json} in every
 * resource pack (the mod's own built-in pack first). A later pack can replace a station by shipping a
 * file with the same path, or add new ones. Files that do not parse or validate are skipped and logged.
 *
 * <p>Reloaded with the client's resources (F3+T, pack changes). Read on the client main thread.
 */
public final class StationRegistry {
	private static final String FOLDER = "stations";
	private static volatile Map<String, StationDefinition> stations = Map.of();

	private StationRegistry() {
	}

	/** Registers the reload listener; call once from the client initializer. */
	public static void register() {
		ResourceManagerHelper.get(class_3264.field_14188).registerReloadListener(new SimpleSynchronousResourceReloadListener() {
			@Override
			public class_2960 getFabricId() {
				return FadoECravo.id("stations");
			}

			@Override
			public void method_14491(class_3300 manager) {
				load(manager);
			}
		});
	}

	/** All loaded stations, ordered by frequency. */
	public static Collection<StationDefinition> all() {
		return stations.values();
	}

	public static Optional<StationDefinition> get(String id) {
		return Optional.ofNullable(stations.get(id));
	}

	private static void load(class_3300 manager) {
		Map<String, StationDefinition> loaded = new LinkedHashMap<>();
		Map<class_2960, class_3298> files = manager.method_14488(FOLDER, path -> path.method_12832().endsWith(".json"));
		for (Map.Entry<class_2960, class_3298> entry : files.entrySet()) {
			class_2960 file = entry.getKey();
			try (Reader reader = entry.getValue().method_43039()) {
				JsonElement json = JsonParser.parseReader(reader);
				StationDefinition.parse(json).resultOrPartial(error ->
						FadoECravo.LOGGER.error("Skipping station file {}: {}", file, error))
					.ifPresent(station -> loaded.put(station.id(), station));
			} catch (Exception e) {
				FadoECravo.LOGGER.error("Skipping station file {}: could not read it", file, e);
			}
		}
		Map<String, StationDefinition> sorted = new LinkedHashMap<>();
		loaded.values().stream()
			.sorted(Comparator.comparingInt(StationDefinition::frequencyKhz).thenComparing(StationDefinition::id))
			.forEach(station -> sorted.put(station.id(), station));
		stations = Collections.unmodifiableMap(sorted);
		FadoECravo.LOGGER.info("Loaded {} radio stations: {}", sorted.size(), sorted.keySet());
	}
}
