package com.manzarig.fadoecravo.client.gui;

import com.manzarig.fadoecravo.RadioClientBridge;
import com.manzarig.fadoecravo.block.RadioBlock;
import com.manzarig.fadoecravo.block.entity.RadioBlockEntity;
import com.manzarig.fadoecravo.broadcast.StationDefinition;
import com.manzarig.fadoecravo.broadcast.Tuning;
import com.manzarig.fadoecravo.client.station.StationRegistry;
import com.manzarig.fadoecravo.net.ModNetworking;
import com.manzarig.fadoecravo.net.SetFrequencyPayload;
import com.manzarig.fadoecravo.net.TogglePowerPayload;
import com.manzarig.fadoecravo.registry.ModBlocks;
import com.manzarig.fadoecravo.registry.ModSounds;
import net.fabricmc.fabric.api.client.networking.v1.ClientPlayNetworking;
import net.minecraft.class_1109;
import net.minecraft.class_156;
import net.minecraft.class_2338;
import net.minecraft.class_2561;
import net.minecraft.class_2680;
import net.minecraft.class_310;
import net.minecraft.class_332;
import net.minecraft.class_3419;
import net.minecraft.class_4185;
import net.minecraft.class_437;
import net.minecraft.class_4587;
import net.minecraft.class_5250;
import net.minecraft.class_5819;
import net.minecraft.class_638;
import net.minecraft.class_6381;
import net.minecraft.class_6382;
import net.minecraft.class_746;
import net.minecraft.class_7919;
import net.minecraft.class_8710;
import org.lwjgl.glfw.GLFW;

/**
 * The tuning screen of a radio: a dial with a needle, the frequency and station that are tuned in, a
 * signal meter and a power button. It has no container and does not pause the game, so the radio
 * keeps playing while the player tunes it.
 *
 * <p>Everything is drawn with {@link class_332#method_25294} in the Terracotta palette; textures come
 * later. Where things go is in {@link RadioLayout}, the dial arithmetic in {@link DialGeometry} and
 * the bookkeeping that keeps the needle from jumping in {@link FrequencySync}.
 *
 * <p>The frequency can be changed with the mouse wheel (1 kHz, 10 kHz with Shift), the left and
 * right arrow keys (the same) and by clicking or dragging on the dial. The change shows at once and
 * is sent to the server 250 ms after the last one, and when the screen closes.
 */
public class RadioScreen extends class_437 {
	private static final String KEY_TITLE = "gui.fadoecravo.radio.title";
	private static final String KEY_POWER_ON = "gui.fadoecravo.radio.power_on";
	private static final String KEY_POWER_OFF = "gui.fadoecravo.radio.power_off";
	private static final String KEY_FREQUENCY = "gui.fadoecravo.radio.frequency";
	private static final String KEY_STATIC = "gui.fadoecravo.radio.static";
	private static final String KEY_SIGNAL_LOCKED = "gui.fadoecravo.radio.signal_locked";
	private static final String KEY_NO_STATION = "gui.fadoecravo.radio.no_station";
	private static final String KEY_TUNE_HINT = "gui.fadoecravo.radio.tune_hint";
	private static final String KEY_SIGNAL = "gui.fadoecravo.radio.signal";
	private static final String KEY_OFF_AIR = "gui.fadoecravo.radio.off_air";
	private static final String KEY_POWER = "gui.fadoecravo.radio.power";

	// Terracotta palette (CLAUDE.md), as opaque ARGB.
	private static final int TERRACOTTA = 0xFFBD5D37;
	private static final int UMBER = 0xFF663A29;
	private static final int ALABASTER = 0xFFEDDFDA;
	private static final int CHARCOAL = 0xFF262322;
	private static final int SAFFRON = 0xFFD1C42E;
	private static final int GARNET = 0xFFA8190F;
	/** Alabaster, a little dimmed: 5:1 against umber and 11:1 against charcoal, for the small text. */
	private static final int ALABASTER_DIM = 0xFFC9B8AF;

	/** Wheel and arrow keys: 1 kHz, or 10 kHz with Shift. */
	private static final int STEP_KHZ = 1;
	private static final int BIG_STEP_KHZ = 10;
	private static final float WHISTLE_VOLUME = 0.7f;
	private static final long WHISTLE_COOLDOWN_MS = 300L;
	/** Smallest scale text is squeezed to before it is cut short. */
	private static final float MIN_TEXT_SCALE = 0.6f;

	private final class_2338 pos;
	private final DialGeometry dial = new DialGeometry(RadioLayout.DIAL_LEFT, RadioLayout.DIAL_WIDTH);
	private final FrequencySync sync;
	private final Cooldown whistleCooldown = new Cooldown(WHISTLE_COOLDOWN_MS);
	private class_4185 powerButton;
	/** Top left corner of the panel on the screen. */
	private int panelX;
	private int panelY;
	private boolean draggingDial;

	/** Sets {@link RadioClientBridge} so that using a radio block opens this screen. Call once from the client initializer. */
	public static void register() {
		RadioClientBridge.setScreenOpener(pos -> class_310.method_1551().method_1507(new RadioScreen(pos)));
	}

	public RadioScreen(class_2338 pos) {
		super(class_2561.method_43471(KEY_TITLE));
		this.pos = pos.method_10062();
		int initial = RadioBlockEntity.DEFAULT_KHZ;
		class_638 level = class_310.method_1551().field_1687;
		if (level != null && level.method_8321(this.pos) instanceof RadioBlockEntity radio) {
			initial = radio.getFrequencyKhz();
		}
		this.sync = new FrequencySync(initial, RadioBlockEntity.MIN_KHZ, RadioBlockEntity.MAX_KHZ);
	}

	// ------------------------------------------------------------------ screen lifecycle

	@Override
	public boolean method_25421() {
		return false;
	}

	@Override
	protected void method_25426() {
		panelX = Math.max(0, (field_22789 - RadioLayout.PANEL_W) / 2);
		panelY = Math.max(0, (field_22790 - RadioLayout.PANEL_H) / 2);
		RadioLayout.Rect b = RadioLayout.POWER_BUTTON;
		powerButton = method_37063(class_4185.method_46430(powerLabel(isOn()), button -> sendTogglePower())
			.method_46434(panelX + b.x(), panelY + b.y(), b.w(), b.h())
			.method_46436(class_7919.method_47407(class_2561.method_43471(KEY_POWER)))
			.method_46431());
	}

	@Override
	public void method_25393() {
		super.method_25393();
		class_638 level = class_310.method_1551().field_1687;
		class_746 player = class_310.method_1551().field_1724;
		if (level == null || player == null) {
			closeWithoutSending();
			return;
		}
		class_2680 state = level.method_8320(pos);
		if (!state.method_27852(ModBlocks.RADIO) || !(level.method_8321(pos) instanceof RadioBlockEntity radio)) {
			closeWithoutSending();
			return;
		}
		// The same measure the server applies to the packets, so that the screen goes away
		// before the server would start ignoring it.
		if (!ModNetworking.isInReach(player.method_5649(pos.method_10263() + 0.5, pos.method_10264() + 0.5, pos.method_10260() + 0.5))) {
			closeWithoutSending();
			return;
		}
		long now = class_156.method_658();
		sync.onServerValue(radio.getFrequencyKhz(), now);
		sync.pollSend(now).ifPresent(this::sendFrequency);
		powerButton.method_25355(powerLabel(state.method_11654(RadioBlock.ON)));
	}

	/** Called whenever the screen is replaced or closed, so an unsent frequency goes out here. */
	@Override
	public void method_25432() {
		super.method_25432();
		sync.flush(class_156.method_658()).ifPresent(this::sendFrequency);
	}

	private void closeWithoutSending() {
		sync.discardPending();
		method_25419();
	}

	// ------------------------------------------------------------------ input

	@Override
	public boolean method_25401(double mouseX, double mouseY, double scrollX, double scrollY) {
		// With Shift held some platforms turn the wheel into a sideways scroll.
		double amount = scrollY != 0.0 ? scrollY : scrollX;
		if (amount == 0.0) {
			return super.method_25401(mouseX, mouseY, scrollX, scrollY);
		}
		nudge((int) Math.signum(amount) * (method_25442() ? BIG_STEP_KHZ : STEP_KHZ));
		return true;
	}

	@Override
	public boolean method_25402(double mouseX, double mouseY, int button) {
		if (button == 0 && RadioLayout.STRIP.contains(mouseX - panelX, mouseY - panelY)) {
			draggingDial = true;
			method_25395(null);
			setFromMouse(mouseX);
			return true;
		}
		return super.method_25402(mouseX, mouseY, button);
	}

	@Override
	public boolean method_25403(double mouseX, double mouseY, int button, double dragX, double dragY) {
		if (draggingDial && button == 0) {
			setFromMouse(mouseX);
			return true;
		}
		return super.method_25403(mouseX, mouseY, button, dragX, dragY);
	}

	@Override
	public boolean method_25406(double mouseX, double mouseY, int button) {
		if (button == 0 && draggingDial) {
			draggingDial = false;
			return true;
		}
		return super.method_25406(mouseX, mouseY, button);
	}

	@Override
	public boolean method_25404(int keyCode, int scanCode, int modifiers) {
		// Before the default handling, which would use the arrow keys to move the focus.
		if (keyCode == GLFW.GLFW_KEY_LEFT || keyCode == GLFW.GLFW_KEY_RIGHT) {
			int step = (modifiers & GLFW.GLFW_MOD_SHIFT) != 0 ? BIG_STEP_KHZ : STEP_KHZ;
			nudge(keyCode == GLFW.GLFW_KEY_RIGHT ? step : -step);
			return true;
		}
		if (field_22787 != null && field_22787.field_1690.field_1822.method_1417(keyCode, scanCode)) {
			method_25419();
			return true;
		}
		return super.method_25404(keyCode, scanCode, modifiers);
	}

	private void setFromMouse(double mouseX) {
		applyChange(dial.khzForX(mouseX - panelX));
	}

	private void nudge(int deltaKhz) {
		applyChange(sync.shown() + deltaKhz);
	}

	/** Shows a new frequency now, whistles if the needle came into a station's window, and queues the send. */
	private void applyChange(int khz) {
		int previous = sync.shown();
		long now = class_156.method_658();
		if (!sync.set(khz, now)) {
			return;
		}
		// A radio that is switched off is silent, so it does not whistle either.
		if (isOn() && DialGeometry.entersAnyWindow(previous, sync.shown(), stationFrequencies(), Tuning.CLEAR_KHZ)
			&& whistleCooldown.tryAcquire(now)) {
			playWhistle();
		}
	}

	private static int[] stationFrequencies() {
		return StationRegistry.all().stream().mapToInt(StationDefinition::frequencyKhz).toArray();
	}

	private void playWhistle() {
		class_310.method_1551().method_1483().method_4873(new class_1109(ModSounds.TUNING_WHISTLE,
			class_3419.field_15247, WHISTLE_VOLUME, 1.0f, class_5819.method_43047(),
			pos.method_10263() + 0.5, pos.method_10264() + 0.5, pos.method_10260() + 0.5));
	}

	// ------------------------------------------------------------------ networking

	private void sendFrequency(int khz) {
		if (canSend(SetFrequencyPayload.TYPE)) {
			ClientPlayNetworking.send(new SetFrequencyPayload(pos, khz));
		}
	}

	private void sendTogglePower() {
		if (canSend(TogglePowerPayload.TYPE)) {
			ClientPlayNetworking.send(new TogglePowerPayload(pos));
		}
	}

	/** False when there is no connection (the screen is being torn down) or the server cannot take the packet. */
	private static boolean canSend(class_8710.class_9154<?> type) {
		return class_310.method_1551().method_1562() != null && ClientPlayNetworking.canSend(type);
	}

	// ------------------------------------------------------------------ state

	private boolean isOn() {
		class_638 level = class_310.method_1551().field_1687;
		return level != null && level.method_8320(pos).method_28500(RadioBlock.ON).orElse(false);
	}

	private static class_2561 powerLabel(boolean on) {
		return class_2561.method_43471(on ? KEY_POWER_ON : KEY_POWER_OFF);
	}

	private RadioReadout readout() {
		class_638 level = class_310.method_1551().field_1687;
		long dayTime = level == null ? 0L : level.method_8532();
		return RadioReadout.of(StationRegistry.all(), sync.shown(), dayTime);
	}

	private static class_2561 stationName(StationDefinition station) {
		return class_2561.method_43471(station.name());
	}

	private static class_2561 frequencyText(int khz) {
		return class_2561.method_43469(KEY_FREQUENCY, khz);
	}

	// ------------------------------------------------------------------ narration

	@Override
	protected void method_37056(class_6382 output) {
		output.method_37034(class_6381.field_33789, describe());
		super.method_37056(output);
	}

	/** The frequency and what is on it, for the narrator. */
	private class_2561 describe() {
		RadioReadout readout = readout();
		class_5250 text = frequencyText(sync.shown()).method_27661();
		switch (readout.status()) {
			case NO_STATION -> text.method_27693(", ").method_10852(class_2561.method_43471(KEY_NO_STATION));
			case OFF_AIR -> text.method_27693(", ").method_10852(stationName(readout.station()))
				.method_27693(", ").method_10852(class_2561.method_43471(KEY_OFF_AIR));
			case ON_AIR -> {
				text.method_27693(", ").method_10852(stationName(readout.station()));
				if (readout.locked()) {
					text.method_27693(", ").method_10852(class_2561.method_43471(KEY_SIGNAL_LOCKED));
				}
			}
		}
		return text;
	}

	// ------------------------------------------------------------------ drawing

	/**
	 * The world is dimmed a little instead of blurred, and the whole panel is drawn here, because
	 * {@link class_437#method_25394} calls this first and draws the button afterwards, on top.
	 */
	@Override
	public void method_25420(class_332 graphics, int mouseX, int mouseY, float partialTick) {
		method_52752(graphics);
		drawFrame(graphics);
		drawDial(graphics);
		drawReadout(graphics);
		drawPowerRow(graphics);
	}

	@Override
	public void method_25394(class_332 graphics, int mouseX, int mouseY, float partialTick) {
		super.method_25394(graphics, mouseX, mouseY, partialTick);
		drawStationTooltip(graphics, mouseX, mouseY);
	}

	private void drawFrame(class_332 g) {
		int x = panelX;
		int y = panelY;
		int w = RadioLayout.PANEL_W;
		int h = RadioLayout.PANEL_H;
		int b = RadioLayout.BORDER;
		g.method_25294(x, y, x + w, y + h, CHARCOAL);
		g.method_25294(x + b, y + b, x + w - b, y + h - b, UMBER);
		// A lit top and left edge and a shaded bottom and right edge.
		g.method_25294(x + b, y + b, x + w - b, y + b + 1, TERRACOTTA);
		g.method_25294(x + b, y + b, x + b + 1, y + h - b, TERRACOTTA);
		g.method_25294(x + b, y + h - b - 1, x + w - b, y + h - b, CHARCOAL);
		g.method_25294(x + w - b - 1, y + b, x + w - b, y + h - b, CHARCOAL);
		// Rivets in the corners.
		int rivet = 2;
		int[] rx = {x + 6, x + w - 6 - rivet};
		int[] ry = {y + 6, y + h - 6 - rivet};
		for (int cx : rx) {
			for (int cy : ry) {
				g.method_25294(cx, cy, cx + rivet, cy + rivet, TERRACOTTA);
			}
		}
		g.method_27534(field_22793, field_22785, x + w / 2, y + RadioLayout.TITLE_Y, ALABASTER);
	}

	private void drawDial(class_332 g) {
		RadioLayout.Rect strip = RadioLayout.STRIP;
		int sx = panelX + strip.x();
		int sy = panelY + strip.y();
		g.method_25294(sx - 1, sy - 1, sx + strip.w() + 1, sy + strip.h() + 1, CHARCOAL);
		g.method_25294(sx, sy, sx + strip.w(), sy + strip.h(), ALABASTER);

		// Ticks, standing on a base line.
		int baseY = panelY + RadioLayout.TICK_BASE_Y;
		g.method_25294(panelX + dial.left(), baseY, panelX + dial.left() + dial.width() + 1, baseY + 1, CHARCOAL);
		for (int khz = dial.firstTickKhz(); khz <= dial.lastTickKhz(); khz += DialGeometry.TICK_STEP_KHZ) {
			int tx = panelX + dial.tickX(khz);
			boolean major = DialGeometry.isMajor(khz);
			int tickH = major ? RadioLayout.TICK_MAJOR_H : RadioLayout.TICK_MINOR_H;
			g.method_25294(tx, baseY - tickH, tx + 1, baseY, major ? CHARCOAL : UMBER);
		}

		// Numbers. The last one would stick out of the strip if it were centred on its tick.
		for (int khz = DialGeometry.FIRST_LABEL_KHZ; khz <= dial.lastTickKhz(); khz += DialGeometry.LABEL_STEP_KHZ) {
			String label = Integer.toString(khz);
			int labelW = field_22793.method_1727(label);
			double centre = panelX + dial.centerX(khz);
			int lx = (int) Math.round(centre - (labelW - 1) / 2.0);
			lx = Math.max(sx + RadioLayout.LABEL_EDGE_PAD, Math.min(sx + strip.w() - RadioLayout.LABEL_EDGE_PAD - labelW, lx));
			g.method_51433(field_22793, label, lx, panelY + RadioLayout.LABEL_Y, CHARCOAL, false);
		}

		// Station marks: a terracotta pin pointing at the tick.
		for (StationDefinition station : StationRegistry.all()) {
			int tx = panelX + dial.tickX(station.frequencyKhz());
			int top = panelY + RadioLayout.MARK_Y;
			int half = RadioLayout.MARK_HALF_WIDTH;
			g.method_25294(tx - half, top, tx + half + 1, top + 1, TERRACOTTA);
			g.method_25294(tx - half + 1, top + 1, tx + half, top + 2, TERRACOTTA);
			g.method_25294(tx, top + 2, tx + 1, top + RadioLayout.MARK_H, TERRACOTTA);
		}

		// Needle.
		int nx = panelX + dial.tickX(sync.shown());
		int half = RadioLayout.NEEDLE_HALF_WIDTH;
		int cap = RadioLayout.NEEDLE_CAP_HALF_WIDTH;
		g.method_25294(nx - half, panelY + RadioLayout.NEEDLE_TOP, nx + half + 1, panelY + RadioLayout.NEEDLE_BOTTOM, GARNET);
		g.method_25294(nx - cap, panelY + RadioLayout.NEEDLE_TOP, nx + cap + 1,
			panelY + RadioLayout.NEEDLE_TOP + RadioLayout.NEEDLE_CAP_HEIGHT, GARNET);
	}

	private void drawReadout(class_332 g) {
		RadioLayout.Rect box = RadioLayout.READOUT;
		g.method_25294(panelX + box.x(), panelY + box.y(), panelX + box.right(), panelY + box.bottom(), CHARCOAL);

		RadioReadout readout = readout();
		int leftX = panelX + RadioLayout.LEFT_COL_X;
		int rightX = panelX + RadioLayout.RIGHT_COL_X;

		// Left column: frequency, then the station or what the dial is picking up instead.
		drawFitted(g, frequencyText(sync.shown()), leftX, panelY + RadioLayout.FREQ_Y, RadioLayout.LEFT_COL_W,
			RadioLayout.FREQ_SCALE, SAFFRON, true, false);
		switch (readout.status()) {
			case NO_STATION -> {
				drawFitted(g, class_2561.method_43471(KEY_STATIC), leftX, panelY + RadioLayout.NAME_Y,
					RadioLayout.LEFT_COL_W, 1.0f, ALABASTER, true, false);
				drawFitted(g, class_2561.method_43471(KEY_NO_STATION), leftX, panelY + RadioLayout.SUB_Y,
					RadioLayout.LEFT_COL_W, RadioLayout.SUB_SCALE, ALABASTER_DIM, false, false);
			}
			case OFF_AIR -> {
				drawFitted(g, stationName(readout.station()), leftX, panelY + RadioLayout.NAME_Y,
					RadioLayout.LEFT_COL_W, 1.0f, ALABASTER, true, false);
				drawFitted(g, class_2561.method_43471(KEY_OFF_AIR), leftX, panelY + RadioLayout.SUB_Y,
					RadioLayout.LEFT_COL_W, RadioLayout.SUB_SCALE, ALABASTER_DIM, false, false);
			}
			case ON_AIR -> drawFitted(g, stationName(readout.station()), leftX, panelY + RadioLayout.NAME_Y,
				RadioLayout.LEFT_COL_W, 1.0f, ALABASTER, true, false);
		}

		// Right column: signal meter, and "locked" when the programme comes in at full strength.
		drawFitted(g, class_2561.method_43471(KEY_SIGNAL), rightX, panelY + RadioLayout.SIGNAL_LABEL_Y,
			RadioLayout.RIGHT_COL_W, 1.0f, ALABASTER, true, false);
		drawSignalBar(g, readout.signal());
		if (readout.locked()) {
			drawFitted(g, class_2561.method_43471(KEY_SIGNAL_LOCKED), rightX, panelY + RadioLayout.LOCKED_Y,
				RadioLayout.RIGHT_COL_W, 1.0f, SAFFRON, true, false);
		}

		// Hint, centred under the readout.
		RadioLayout.Rect hint = RadioLayout.HINT;
		drawFitted(g, class_2561.method_43471(KEY_TUNE_HINT), panelX + hint.x(), panelY + hint.y(), hint.w(),
			RadioLayout.HINT_SCALE, ALABASTER_DIM, false, true);
	}

	/** A meter of 10 segments: a terracotta frame, an umber track and saffron filling it up to {@code signal}. */
	private void drawSignalBar(class_332 g, double signal) {
		RadioLayout.Rect bar = RadioLayout.SIGNAL_BAR;
		int x = panelX + bar.x();
		int y = panelY + bar.y();
		g.method_25294(x, y, x + bar.w(), y + bar.h(), TERRACOTTA);
		RadioLayout.Rect inner = bar.inset(1);
		int ix = panelX + inner.x();
		int iy = panelY + inner.y();
		g.method_25294(ix, iy, ix + inner.w(), iy + inner.h(), UMBER);
		int filled = (int) Math.round(Math.max(0.0, Math.min(1.0, signal)) * inner.w());
		if (filled > 0) {
			g.method_25294(ix, iy, ix + filled, iy + inner.h(), SAFFRON);
		}
		int pitch = RadioLayout.SIGNAL_SEGMENT_W + 1;
		for (int i = 1; i < RadioLayout.SIGNAL_SEGMENTS; i++) {
			int gx = ix + i * pitch - 1;
			g.method_25294(gx, iy, gx + 1, iy + inner.h(), CHARCOAL);
		}
	}

	private void drawPowerRow(class_332 g) {
		RadioLayout.Rect lamp = RadioLayout.LAMP;
		int lx = panelX + lamp.x();
		int ly = panelY + lamp.y();
		boolean on = isOn();
		// A round lamp: a charcoal ring around a saffron (on) or umber (off) glass.
		g.method_25294(lx + 1, ly, lx + lamp.w() - 1, ly + lamp.h(), CHARCOAL);
		g.method_25294(lx, ly + 1, lx + lamp.w(), ly + lamp.h() - 1, CHARCOAL);
		g.method_25294(lx + 2, ly + 1, lx + lamp.w() - 2, ly + lamp.h() - 1, on ? SAFFRON : UMBER);
		g.method_25294(lx + 1, ly + 2, lx + lamp.w() - 1, ly + lamp.h() - 2, on ? SAFFRON : UMBER);
		if (on) {
			g.method_25294(lx + 2, ly + 2, lx + 4, ly + 4, ALABASTER);
		}
		String label = class_2561.method_43471(KEY_POWER).getString();
		int labelX = Math.max(panelX + RadioLayout.INTERIOR.x() + 4, panelX + RadioLayout.POWER_LABEL_RIGHT - field_22793.method_1727(label));
		g.method_51433(field_22793, label, labelX, panelY + RadioLayout.POWER_BUTTON.y() + (RadioLayout.POWER_BUTTON.h() - field_22793.field_2000) / 2 + 1,
			ALABASTER, true);
	}

	/** Names a station when the mouse rests on its pin on the dial. */
	private void drawStationTooltip(class_332 g, int mouseX, int mouseY) {
		int top = panelY + RadioLayout.MARK_Y - 1;
		if (mouseY < top || mouseY >= top + RadioLayout.MARK_H + 2) {
			return;
		}
		for (StationDefinition station : StationRegistry.all()) {
			int tx = panelX + dial.tickX(station.frequencyKhz());
			if (mouseX >= tx - RadioLayout.MARK_HALF_WIDTH - 1 && mouseX < tx + RadioLayout.MARK_HALF_WIDTH + 2) {
				class_2561 text = class_2561.method_43473().method_10852(stationName(station)).method_27693(" - ")
					.method_10852(frequencyText(station.frequencyKhz()));
				g.method_51438(field_22793, text, mouseX, mouseY);
				return;
			}
		}
	}

	/**
	 * Draws text at {@code scale}, squeezed (down to {@link #MIN_TEXT_SCALE}) and then cut short with
	 * dots so that it fits in {@code maxWidth}; some translations are long.
	 *
	 * @param centered whether to centre the text in {@code maxWidth} instead of starting at {@code x}
	 */
	private void drawFitted(class_332 g, class_2561 text, int x, int y, int maxWidth, float scale, int color,
		boolean shadow, boolean centered) {
		String s = text.getString();
		int natural = field_22793.method_1727(s);
		if (natural == 0) {
			return;
		}
		float used = scale;
		if (natural * used > maxWidth) {
			used = Math.max(MIN_TEXT_SCALE, Math.min(scale, maxWidth / (float) natural));
		}
		int room = (int) (maxWidth / used);
		if (natural > room) {
			s = field_22793.method_27523(s, room - field_22793.method_1727("...")) + "...";
			natural = field_22793.method_1727(s);
		}
		int dx = centered ? Math.round((maxWidth - natural * used) / 2f) : 0;
		if (used == 1.0f) {
			g.method_51433(field_22793, s, x + dx, y, color, shadow);
			return;
		}
		class_4587 pose = g.method_51448();
		pose.method_22903();
		pose.method_46416(x + dx, y, 0f);
		pose.method_22905(used, used, 1f);
		g.method_51433(field_22793, s, 0, 0, color, shadow);
		pose.method_22909();
	}
}
