package com.manzarig.fadoecravo.client.debug;

import static net.fabricmc.fabric.api.client.command.v2.ClientCommandManager.argument;
import static net.fabricmc.fabric.api.client.command.v2.ClientCommandManager.literal;

import com.manzarig.fadoecravo.client.audio.RadioSoundInstance;
import com.mojang.brigadier.arguments.DoubleArgumentType;
import net.fabricmc.fabric.api.client.command.v2.ClientCommandRegistrationCallback;
import net.fabricmc.fabric.api.client.command.v2.FabricClientCommandSource;
import net.fabricmc.loader.api.FabricLoader;
import net.minecraft.class_2338;
import net.minecraft.class_2561;
import net.minecraft.class_2960;
import net.minecraft.class_310;
import net.minecraft.class_746;

/**
 * Development-only client command for checking by ear that a radio can start a clip partway in.
 * {@code /fadoecravo_seektest <seconds>} plays {@code test/seek_test.ogg} from that offset, and
 * {@code /fadoecravo_seektest stop} fades it out. The clip is a 60 s tone that rises 100 Hz every
 * 5 s, from 300 Hz, so the pitch tells where playback started.
 */
public final class SeekTestCommand {
	private static final class_2960 SOUND_ID = class_2960.method_60655("fadoecravo", "test.seek_test");
	private static RadioSoundInstance current;

	private SeekTestCommand() {
	}

	/** Registers the command, but only in a development environment. */
	public static void register() {
		if (!FabricLoader.getInstance().isDevelopmentEnvironment()) {
			return;
		}
		ClientCommandRegistrationCallback.EVENT.register((dispatcher, registryAccess) ->
			dispatcher.register(literal("fadoecravo_seektest")
				.then(literal("stop").executes(context -> stop(context.getSource())))
				.then(argument("seconds", DoubleArgumentType.doubleArg(0.0, 60.0))
					.executes(context -> play(context.getSource(), DoubleArgumentType.getDouble(context, "seconds"))))));
	}

	private static int play(FabricClientCommandSource source, double seconds) {
		class_746 player = source.getPlayer();
		class_310 client = source.getClient();
		stopCurrent();
		class_2338 pos = player.method_24515().method_10084().method_10079(player.method_5735(), 2);
		current = new RadioSoundInstance(SOUND_ID, pos, seconds, 1.0f);
		client.method_1483().method_4873(current);
		source.sendFeedback(class_2561.method_43470("Seek test: " + SOUND_ID + " from " + seconds + " s at " + pos.method_23854()));
		return 1;
	}

	private static int stop(FabricClientCommandSource source) {
		stopCurrent();
		source.sendFeedback(class_2561.method_43470("Seek test stopped"));
		return 1;
	}

	private static void stopCurrent() {
		if (current != null) {
			current.fadeOutAndStop();
			current = null;
		}
	}
}
