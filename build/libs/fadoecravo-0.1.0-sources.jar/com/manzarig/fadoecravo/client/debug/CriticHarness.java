package com.manzarig.fadoecravo.client.debug;

import com.google.gson.JsonArray;
import com.google.gson.JsonObject;
import com.mojang.logging.LogUtils;
import com.manzarig.fadoecravo.RadioClientBridge;
import com.manzarig.fadoecravo.block.entity.RadioBlockEntity;
import com.manzarig.fadoecravo.client.audio.RadioAudioManager;
import com.manzarig.fadoecravo.client.audio.RadioDebugState;
import com.manzarig.fadoecravo.client.gui.DialGeometry;
import com.manzarig.fadoecravo.client.gui.RadioLayout;
import com.manzarig.fadoecravo.client.gui.RadioScreen;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.nio.file.StandardCopyOption;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import java.util.function.Function;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.message.v1.ClientReceiveMessageEvents;
import net.fabricmc.fabric.api.client.rendering.v1.WorldRenderEvents;
import net.fabricmc.loader.api.FabricLoader;
import net.minecraft.class_1011;
import net.minecraft.class_1109;
import net.minecraft.class_124;
import net.minecraft.class_1267;
import net.minecraft.class_1928;
import net.minecraft.class_1934;
import net.minecraft.class_1940;
import net.minecraft.class_2338;
import net.minecraft.class_2561;
import net.minecraft.class_2680;
import net.minecraft.class_2960;
import net.minecraft.class_310;
import net.minecraft.class_318;
import net.minecraft.class_32;
import net.minecraft.class_329;
import net.minecraft.class_339;
import net.minecraft.class_3414;
import net.minecraft.class_359;
import net.minecraft.class_364;
import net.minecraft.class_4185;
import net.minecraft.class_424;
import net.minecraft.class_437;
import net.minecraft.class_442;
import net.minecraft.class_5251;
import net.minecraft.class_5285;
import net.minecraft.class_5317;
import net.minecraft.class_5455;
import net.minecraft.class_638;
import net.minecraft.class_746;
import net.minecraft.class_7712;
import net.minecraft.class_7723;
import net.minecraft.class_7924;
import net.minecraft.class_8032;
import org.lwjgl.glfw.GLFW;
import org.slf4j.Logger;

/**
 * A development-only robot that plays the game for a "critic": it creates a world, walks through the
 * steps of a scenario file and writes down what it did and what the radios were doing, so that an
 * outside agent can judge the mod from screenshots, a recording of the real audio mix and a log,
 * without a person at the keyboard.
 *
 * <p><b>Enabled only</b> in a development environment, and only when the system property
 * {@value #PROPERTY_SCENARIO} names a scenario JSON ({@link CriticScenario}). {@link #register()}
 * does nothing otherwise, so shipping builds are never affected. {@code tools/critic/run_critic.sh}
 * sets everything up; the step reference is in {@code tools/critic/README.md}.
 *
 * <p><b>Output</b> goes to the directory named by {@value #PROPERTY_OUT} (default
 * {@code build/critic/<scenario name>}): {@code playback.log} (one JSON object per line),
 * {@code shots/NN_name.png}, and a copy of the scenario. The audio recording is made by OpenAL
 * itself (its "Wave File Writer" backend, switched on by the script's environment), not by this class.
 *
 * <p><b>How it runs.</b> Everything happens on the client thread in the end-of-tick event. First it
 * waits on the title screen, creates a fresh world (superflat by default, creative, cheats on, fixed
 * seed, no mobs, no weather, no insomnia), waits until the player has been in the world for a
 * while, and then runs the steps in order. A step either finishes within the tick or makes the
 * runner wait for later ticks ({@code wait}, {@code shot}, {@code quit}). A screenshot is taken only
 * after two frames have been drawn since the step before it, so it shows the state that step caused.
 */
public final class CriticHarness {
	/** System property: absolute path of the scenario JSON. */
	public static final String PROPERTY_SCENARIO = "fadoecravo.critic";
	/** System property: absolute path of the output directory. */
	public static final String PROPERTY_OUT = "fadoecravo.critic.out";

	private static final Logger LOGGER = LogUtils.getLogger();
	private static final String WORLD_ID = "fadoecravo_critic_world";
	private static final class_2960 MARK_SOUND = class_2960.method_60655("fadoecravo", "test.seek_test");
	private static final float MARK_VOLUME = 0.6f;
	/** Frames that must be drawn after a step before a screenshot shows its effect. */
	private static final int FRAMES_BEFORE_SHOT = 2;
	/** Ticks after which a screenshot is taken even if no frame was drawn (a window that does not render). */
	private static final int SHOT_GIVE_UP_TICKS = 200;
	/** Ticks on the title screen before the world is created, for the resource reload to settle. */
	private static final int TITLE_SETTLE_TICKS = 30;
	/** Ticks the world may take to appear before the run is abandoned. */
	private static final int LOAD_GIVE_UP_TICKS = 20 * 120;
	/** Real seconds between asking the game to stop and halting the JVM if it is stuck. */
	private static final int HALT_AFTER_SECONDS = 90;

	private enum Phase {
		TITLE, LOADING, SETTLING, RUNNING, QUITTING, DONE
	}

	private final CriticScenario scenario;
	private final Path outDir;
	private final Path shotsDir;
	private final CriticLog log;
	private final long startMillis = System.currentTimeMillis();

	private Phase phase = Phase.TITLE;
	private long tick;
	private long phaseStartTick;
	private int stepIndex;
	private long waitUntilTick;
	private int shotCount;
	private int errorCount;
	private int stepsRun;
	private int titleTicks;
	private String pendingShot;
	private long pendingShotTick;
	private long pendingShotFrame;
	private long frames;
	private String lastScreen = "none";
	private class_1109 markSound;
	private long markStopTick;
	private boolean quitRequested;
	private String lastCommand;

	private CriticHarness(CriticScenario scenario, Path outDir, CriticLog log) {
		this.scenario = scenario;
		this.outDir = outDir;
		this.shotsDir = outDir.resolve("shots");
		this.log = log;
	}

	// ------------------------------------------------------------------ registration

	/** Starts the harness if this is a development environment and a scenario was given; does nothing otherwise. */
	public static void register() {
		if (!FabricLoader.getInstance().isDevelopmentEnvironment()) {
			return;
		}
		String scenarioPath = System.getProperty(PROPERTY_SCENARIO);
		if (scenarioPath == null || scenarioPath.isBlank()) {
			return;
		}
		try {
			Path scenarioFile = Paths.get(scenarioPath).toAbsolutePath();
			String outProperty = System.getProperty(PROPERTY_OUT);
			Path outDir = outProperty != null && !outProperty.isBlank()
				? Paths.get(outProperty).toAbsolutePath()
				: FabricLoader.getInstance().getGameDir().toAbsolutePath().resolveSibling("build").resolve("critic")
					.resolve(baseName(scenarioFile));
			Files.createDirectories(outDir.resolve("shots"));
			CriticLog log = new CriticLog(outDir.resolve("playback.log"));
			CriticHarness harness;
			try {
				String text = Files.readString(scenarioFile, StandardCharsets.UTF_8);
				Files.writeString(outDir.resolve("scenario.json"), text, StandardCharsets.UTF_8);
				CriticScenario scenario = CriticScenario.parse(text);
				harness = new CriticHarness(scenario, outDir, log);
			} catch (IOException | CriticScenario.ScenarioException e) {
				JsonObject error = new JsonObject();
				error.addProperty("type", "fatal");
				error.addProperty("wall_ms", System.currentTimeMillis());
				error.addProperty("message", "cannot load scenario " + scenarioFile + ": " + e.getMessage());
				log.write(error);
				log.close();
				LOGGER.error("[critic] cannot load scenario {}: {}", scenarioFile, e.getMessage());
				// Stop the game as soon as the client is up, instead of sitting on the title screen.
				ClientTickEvents.END_CLIENT_TICK.register(class_310::method_1592);
				return;
			}
			harness.start();
		} catch (IOException e) {
			LOGGER.error("[critic] cannot prepare the output directory", e);
		}
	}

	private static String baseName(Path file) {
		String name = file.getFileName().toString();
		int dot = name.lastIndexOf('.');
		return dot > 0 ? name.substring(0, dot) : name;
	}

	private void start() {
		ClientTickEvents.END_CLIENT_TICK.register(this::onTick);
		WorldRenderEvents.START.register(context -> frames++);
		ClientReceiveMessageEvents.GAME.register((message, overlay) -> onChat("game", message, overlay));
		ClientReceiveMessageEvents.CHAT.register((message, signed, sender, params, time) -> onChat("chat", message, false));
		JsonObject o = event("harness_start");
		o.addProperty("scenario_steps", scenario.steps().size());
		o.addProperty("out", outDir.toString());
		o.addProperty("flat", scenario.settings().flat());
		o.addProperty("daylight_cycle", scenario.settings().daylightCycle());
		emit(o);
		LOGGER.info("[critic] harness enabled: {} steps, output in {}", scenario.steps().size(), outDir);
	}

	// ------------------------------------------------------------------ logging

	/** A log line with the fields every line has. */
	private JsonObject event(String type) {
		JsonObject o = new JsonObject();
		o.addProperty("type", type);
		o.addProperty("wall_ms", System.currentTimeMillis());
		o.addProperty("tick", tick);
		class_638 level = class_310.method_1551().field_1687;
		if (level != null) {
			o.addProperty("game_time", level.method_8510());
			o.addProperty("day_time", level.method_8532());
		}
		return o;
	}

	private void emit(JsonObject line) {
		log.write(line);
	}

	private void note(String type, String message) {
		JsonObject o = event(type);
		o.addProperty("message", message);
		emit(o);
	}

	private void warn(String message) {
		errorCount++;
		LOGGER.warn("[critic] {}", message);
		note("warn", message);
	}

	private void onChat(String channel, class_2561 message, boolean overlay) {
		JsonObject o = event("chat");
		o.addProperty("channel", channel);
		o.addProperty("overlay", overlay);
		o.addProperty("text", message.getString());
		// Vanilla paints a failed command red.
		class_5251 color = message.method_10866().method_10973();
		o.addProperty("red", color != null && color.method_27716() == class_124.field_1061.method_532());
		if (lastCommand != null) {
			o.addProperty("after_command", lastCommand);
		}
		emit(o);
	}

	private JsonObject snapshotJson(class_310 mc, String label) {
		JsonObject o = event("snapshot");
		o.addProperty("label", label);
		JsonArray radios = new JsonArray();
		for (RadioDebugState state : RadioAudioManager.snapshot()) {
			JsonObject r = new JsonObject();
			r.add("pos", intArray(state.pos().method_10263(), state.pos().method_10264(), state.pos().method_10260()));
			r.addProperty("khz", state.frequencyKhz());
			r.addProperty("station", state.stationId());
			r.addProperty("signal", round(state.signal(), 3));
			r.addProperty("clip", state.clipId());
			r.addProperty("kind", state.kind());
			r.addProperty("offset_s", round(state.offsetSeconds(), 2));
			r.addProperty("programme_volume", round(state.programmeVolume(), 3));
			r.addProperty("static_volume", round(state.staticVolume(), 3));
			r.addProperty("breaking", state.breaking());
			radios.add(r);
		}
		o.add("radios", radios);
		class_746 player = mc.field_1724;
		if (player != null) {
			JsonObject p = new JsonObject();
			p.addProperty("x", round(player.method_23317(), 2));
			p.addProperty("y", round(player.method_23318(), 2));
			p.addProperty("z", round(player.method_23321(), 2));
			p.addProperty("yaw", round(player.method_36454(), 1));
			p.addProperty("pitch", round(player.method_36455(), 1));
			o.add("player", p);
		}
		o.addProperty("screen", screenName(mc));
		o.addProperty("hud_hidden", mc.field_1690.field_1842);
		o.addProperty("fps", mc.method_47599());
		JsonArray subtitles = new JsonArray();
		for (String text : subtitleTexts(mc)) {
			subtitles.add(text);
		}
		o.add("subtitles", subtitles);
		return o;
	}

	private static JsonArray intArray(int... values) {
		JsonArray a = new JsonArray();
		for (int v : values) {
			a.add(v);
		}
		return a;
	}

	private static double round(double value, int places) {
		double scale = Math.pow(10, places);
		return Math.round(value * scale) / scale;
	}

	private static String screenName(class_310 mc) {
		return mc.field_1755 == null ? "none" : mc.field_1755.getClass().getSimpleName();
	}

	// ------------------------------------------------------------------ subtitles (reflection)

	private static java.lang.reflect.Field subtitleOverlayField;
	private static java.lang.reflect.Field audibleSubtitlesField;
	private static java.lang.reflect.Method subtitleTextMethod;
	private static boolean subtitlesUnavailable;

	/**
	 * The subtitles the overlay drew in the last frame, read with reflection from vanilla's private
	 * {@code SubtitleOverlay.audibleSubtitles}; empty when none are shown, when the HUD is hidden
	 * or if the fields cannot be found.
	 */
	private static List<String> subtitleTexts(class_310 mc) {
		if (subtitlesUnavailable) {
			return List.of();
		}
		try {
			if (subtitleOverlayField == null) {
				subtitleOverlayField = class_329.class.getDeclaredField("subtitleOverlay");
				subtitleOverlayField.setAccessible(true);
				audibleSubtitlesField = class_359.class.getDeclaredField("audibleSubtitles");
				audibleSubtitlesField.setAccessible(true);
				subtitleTextMethod = Class.forName("net.minecraft.client.gui.components.SubtitleOverlay$Subtitle")
					.getDeclaredMethod("getText");
				subtitleTextMethod.setAccessible(true);
			}
			Object overlay = subtitleOverlayField.get(mc.field_1705);
			List<?> audible = new ArrayList<>((List<?>) audibleSubtitlesField.get(overlay));
			List<String> texts = new ArrayList<>();
			for (Object subtitle : audible) {
				texts.add(((class_2561) subtitleTextMethod.invoke(subtitle)).getString());
			}
			return texts;
		} catch (ReflectiveOperationException | RuntimeException e) {
			subtitlesUnavailable = true;
			LOGGER.warn("[critic] cannot read the subtitle overlay: {}", e.toString());
			return List.of();
		}
	}

	// ------------------------------------------------------------------ the tick

	private void onTick(class_310 mc) {
		tick++;
		try {
			trackScreen(mc);
			if (markSound != null && tick >= markStopTick) {
				mc.method_1483().method_4870(markSound);
				markSound = null;
			}
			if (phase != Phase.QUITTING && phase != Phase.DONE
				&& System.currentTimeMillis() - startMillis > scenario.settings().timeoutMinutes() * 60_000L) {
				warn("timeout of " + scenario.settings().timeoutMinutes() + " minutes reached; stopping");
				beginQuit(mc, "timeout");
			}
			switch (phase) {
				case TITLE -> tickTitle(mc);
				case LOADING -> tickLoading(mc);
				case SETTLING -> tickSettling(mc);
				case RUNNING -> tickRunning(mc);
				case QUITTING -> tickQuitting(mc);
				case DONE -> {
				}
			}
			int every = scenario.settings().snapshotEveryTicks();
			if (every > 0 && tick % every == 0 && mc.field_1687 != null && mc.field_1724 != null
				&& (phase == Phase.SETTLING || phase == Phase.RUNNING)) {
				emit(snapshotJson(mc, "periodic"));
			}
		} catch (RuntimeException | Error e) {
			LOGGER.error("[critic] harness failure", e);
			JsonObject o = event("fatal");
			o.addProperty("message", e.toString());
			emit(o);
			errorCount++;
			if (phase != Phase.QUITTING && phase != Phase.DONE) {
				try {
					beginQuit(mc, "exception");
				} catch (RuntimeException second) {
					mc.method_1592();
				}
			}
		}
	}

	private void enter(Phase next) {
		phase = next;
		phaseStartTick = tick;
		note("phase", next.name().toLowerCase(Locale.ROOT));
	}

	/** Logs a line whenever the open screen changes, so a screen that closes itself shows up in the log. */
	private void trackScreen(class_310 mc) {
		String now = screenName(mc);
		if (!now.equals(lastScreen)) {
			JsonObject o = event("screen");
			o.addProperty("from", lastScreen);
			o.addProperty("to", now);
			emit(o);
			lastScreen = now;
		}
	}

	// ------------------------------------------------------------------ startup

	private void tickTitle(class_310 mc) {
		if (mc.field_1687 != null) {
			// Somebody (a previous run's autosave, a quick-play argument) got us into a world already.
			enter(Phase.SETTLING);
			return;
		}
		if (mc.method_18506() != null) {
			return; // still loading resources
		}
		class_437 screen = mc.field_1755;
		if (screen instanceof class_8032) {
			note("dismiss", "AccessibilityOnboardingScreen");
			mc.method_1507(new class_442());
			titleTicks = 0;
			return;
		}
		if (!(screen instanceof class_442)) {
			if (screen != null && ++titleTicks > 60) {
				note("dismiss", screen.getClass().getName());
				mc.method_1507(null); // with no world open the game turns null into the title screen
				titleTicks = 0;
			}
			return;
		}
		if (++titleTicks < TITLE_SETTLE_TICKS) {
			return;
		}
		createWorld(mc);
		enter(Phase.LOADING);
	}

	private void createWorld(class_310 mc) {
		CriticScenario.Settings s = scenario.settings();
		class_32 source = mc.method_1586();
		try {
			if (source.method_230(WORLD_ID)) {
				try (class_32.class_5143 access = source.method_27002(WORLD_ID)) {
					access.method_27015();
				}
			}
		} catch (IOException e) {
			warn("cannot delete the old world " + WORLD_ID + ": " + e);
		}
		class_1928 rules = new class_1928();
		rules.method_20746(class_1928.field_19390).method_20758(false, null);
		rules.method_20746(class_1928.field_19406).method_20758(false, null);
		rules.method_20746(class_1928.field_20637).method_20758(false, null);
		rules.method_20746(class_1928.field_19396).method_20758(s.daylightCycle(), null);
		class_1934 gameType = switch (s.gameMode()) {
			case "survival" -> class_1934.field_9215;
			case "adventure" -> class_1934.field_9216;
			case "spectator" -> class_1934.field_9219;
			default -> class_1934.field_9220;
		};
		class_1940 settings = new class_1940(WORLD_ID, gameType, false, class_1267.field_5801, true, rules,
			class_7712.field_40260);
		class_5285 options = new class_5285(s.seed(), false, false);
		Function<class_5455, class_7723> dimensions = s.flat()
			? access -> access.method_30530(class_7924.field_41250).method_40290(class_5317.field_25054).comp_349()
				.method_45546()
			: class_5317::method_41598;
		JsonObject o = event("create_world");
		o.addProperty("id", WORLD_ID);
		o.addProperty("seed", s.seed());
		o.addProperty("flat", s.flat());
		o.addProperty("game_mode", s.gameMode());
		o.addProperty("daylight_cycle", s.daylightCycle());
		emit(o);
		mc.method_41735().method_41895(WORLD_ID, settings, options, dimensions, mc.field_1755);
	}

	private void tickLoading(class_310 mc) {
		if (mc.field_1687 != null && mc.field_1724 != null) {
			enter(Phase.SETTLING);
			return;
		}
		if (tick - phaseStartTick > LOAD_GIVE_UP_TICKS) {
			warn("the world did not load within " + LOAD_GIVE_UP_TICKS / 20 + " s");
			beginQuit(mc, "load timeout");
		}
	}

	private void tickSettling(class_310 mc) {
		class_746 player = mc.field_1724;
		if (mc.field_1687 == null || player == null) {
			if (tick - phaseStartTick > LOAD_GIVE_UP_TICKS) {
				warn("the player never appeared");
				beginQuit(mc, "load timeout");
			}
			return;
		}
		if (mc.field_1755 != null && tick - phaseStartTick > 200) {
			note("dismiss", mc.field_1755.getClass().getName());
			mc.method_1507(null);
		}
		if (player.field_6012 < scenario.settings().settleTicks() || mc.field_1755 != null || mc.method_1562() == null) {
			return;
		}
		JsonObject o = event("world_ready");
		o.addProperty("player_ticks", player.field_6012);
		o.addProperty("x", round(player.method_23317(), 2));
		o.addProperty("y", round(player.method_23318(), 2));
		o.addProperty("z", round(player.method_23321(), 2));
		o.addProperty("window", mc.method_22683().method_4489() + "x" + mc.method_22683().method_4506());
		o.addProperty("gui_scaled", mc.method_22683().method_4486() + "x" + mc.method_22683().method_4502());
		o.addProperty("gui_scale", mc.method_22683().method_4495());
		o.addProperty("lang", mc.method_1526().method_4669());
		o.addProperty("subtitles_option", mc.field_1690.method_42443().method_41753());
		if (mc.method_1576() != null) {
			class_1928 serverRules = mc.method_1576().method_3767();
			JsonObject r = new JsonObject();
			r.addProperty("doMobSpawning", serverRules.method_8355(class_1928.field_19390));
			r.addProperty("doWeatherCycle", serverRules.method_8355(class_1928.field_19406));
			r.addProperty("doDaylightCycle", serverRules.method_8355(class_1928.field_19396));
			r.addProperty("doInsomnia", serverRules.method_8355(class_1928.field_20637));
			o.add("gamerules", r);
		}
		emit(o);
		scenario.settings().gameRules().forEach((name, value) -> mc.method_1562().method_45730("gamerule " + name + " " + value));
		enter(Phase.RUNNING);
	}

	// ------------------------------------------------------------------ running the steps

	private void tickRunning(class_310 mc) {
		if (mc.field_1687 == null || mc.field_1724 == null) {
			warn("the world went away in the middle of the scenario");
			beginQuit(mc, "world lost");
			return;
		}
		if (pendingShot != null) {
			boolean framesDrawn = frames >= pendingShotFrame + FRAMES_BEFORE_SHOT;
			boolean gaveUp = tick - pendingShotTick > SHOT_GIVE_UP_TICKS;
			if (!framesDrawn && !gaveUp) {
				return;
			}
			if (gaveUp && !framesDrawn) {
				warn("no frame was drawn for " + SHOT_GIVE_UP_TICKS + " ticks; taking the shot anyway");
			}
			takeShot(mc, pendingShot);
			pendingShot = null;
		}
		if (tick < waitUntilTick) {
			return;
		}
		List<CriticScenario.Step> steps = scenario.steps();
		while (stepIndex < steps.size()) {
			CriticScenario.Step step = steps.get(stepIndex++);
			JsonObject o = event("step");
			o.addProperty("index", step.index());
			o.add("step", step.json());
			emit(o);
			stepsRun++;
			boolean yield;
			try {
				yield = execute(mc, step);
			} catch (RuntimeException e) {
				warn("step " + step.index() + " (" + step.kind().key() + ") failed: " + e);
				LOGGER.warn("[critic] step failure", e);
				yield = false;
			}
			if (yield || phase != Phase.RUNNING) {
				return;
			}
		}
		note("end_of_steps", "the scenario ended without a quit step");
		beginQuit(mc, "end of steps");
	}

	/** Runs one step. Returns true when the runner must wait for a later tick before the next one. */
	private boolean execute(class_310 mc, CriticScenario.Step step) {
		switch (step.kind()) {
			case WAIT, WAIT_S -> {
				if (step.amount() > 0) {
					waitUntilTick = tick + step.amount();
					return true;
				}
				return false;
			}
			case CMD -> {
				command(mc, step.text());
				return false;
			}
			case TP -> {
				List<Double> n = step.numbers();
				StringBuilder cmd = new StringBuilder("tp @s");
				for (double v : n) {
					cmd.append(' ').append(number(v));
				}
				command(mc, cmd.toString());
				return false;
			}
			case OPEN -> {
				open(mc, step);
				return false;
			}
			case CLOSE -> {
				if (mc.field_1755 == null) {
					warn("close: no screen is open");
				} else {
					mc.field_1755.method_25419();
				}
				return false;
			}
			case SCROLL -> {
				scroll(mc, step);
				return false;
			}
			case KEY -> {
				key(mc, step);
				return false;
			}
			case CLICK_DIAL_KHZ -> {
				clickDial(mc, step.amount());
				return false;
			}
			case DRAG_DIAL_KHZ -> {
				dragDial(mc, step.numbers().get(0).intValue(), step.numbers().get(1).intValue());
				return false;
			}
			case CLICK_POWER -> {
				clickPower(mc);
				return false;
			}
			case CLICK -> {
				class_437 screen = mc.field_1755;
				if (screen == null) {
					warn("click: no screen is open");
				} else {
					click(screen, step.numbers().get(0), step.numbers().get(1));
				}
				return false;
			}
			case SHOT -> {
				if (!scenario.settings().chatInShots()) {
					mc.field_1705.method_1743().method_1808(false); // command feedback is in the log; keep it out of the picture
				}
				pendingShot = step.text();
				pendingShotTick = tick;
				pendingShotFrame = frames;
				return true;
			}
			case HIDE_HUD -> {
				mc.field_1690.field_1842 = step.flag();
				return false;
			}
			case SNAPSHOT -> {
				emit(snapshotJson(mc, step.text()));
				return false;
			}
			case MARK -> {
				mark(mc, step);
				return false;
			}
			case NOTE -> {
				note("note", step.text());
				return false;
			}
			case QUIT -> {
				beginQuit(mc, "quit step");
				return true;
			}
			default -> throw new IllegalStateException("unhandled step " + step.kind());
		}
	}

	private static String number(double v) {
		return v == Math.rint(v) ? Long.toString((long) v) : String.format(Locale.ROOT, "%.3f", v);
	}

	private void command(class_310 mc, String text) {
		JsonObject o = event("command");
		o.addProperty("command", text);
		emit(o);
		lastCommand = text;
		mc.method_1562().method_45730(text);
	}

	private static String describeBlock(class_310 mc, class_2338 pos) {
		class_2680 state = mc.field_1687.method_8320(pos);
		return state.toString().replace("Block{", "").replace("}", "");
	}

	private void open(class_310 mc, CriticScenario.Step step) {
		List<Double> n = step.numbers();
		class_2338 pos = new class_2338(n.get(0).intValue(), n.get(1).intValue(), n.get(2).intValue());
		JsonObject o = event("open");
		o.add("pos", intArray(pos.method_10263(), pos.method_10264(), pos.method_10260()));
		o.addProperty("block", describeBlock(mc, pos));
		if (mc.field_1687.method_8321(pos) instanceof RadioBlockEntity radio) {
			o.addProperty("block_entity_khz", radio.getFrequencyKhz());
		} else {
			warn("open: there is no radio block entity at " + pos.method_23854());
		}
		o.addProperty("distance", round(Math.sqrt(mc.field_1724.method_5649(pos.method_10263() + 0.5, pos.method_10264() + 0.5, pos.method_10260() + 0.5)), 2));
		RadioClientBridge.openScreen(pos);
		o.addProperty("screen", screenName(mc));
		emit(o);
	}

	/** The middle of the window in GUI coordinates, where the "mouse" rests for the wheel. */
	private static double[] centre(class_437 screen) {
		return new double[] {screen.field_22789 / 2.0, screen.field_22790 / 2.0};
	}

	private RadioScreen radioScreen(class_310 mc, String what) {
		if (mc.field_1755 instanceof RadioScreen screen) {
			return screen;
		}
		warn(what + ": the radio screen is not open (screen is " + screenName(mc) + ")");
		return null;
	}

	private void scroll(class_310 mc, CriticScenario.Step step) {
		RadioScreen screen = radioScreen(mc, "scroll");
		if (screen == null) {
			return;
		}
		double[] at = centre(screen);
		int notches = Math.abs(step.amount());
		double direction = Math.signum(step.amount());
		JsonObject o = event("scroll");
		o.addProperty("notches", step.amount());
		o.addProperty("shift", step.shift());
		if (step.shift()) {
			// Screen.hasShiftDown() reads the real keyboard through GLFW, which cannot be set from here.
			// A Shift-wheel notch is worth 10 plain ones.
			o.addProperty("shift_emulated_as_plain_notches", notches * 10);
			notches *= 10;
		}
		emit(o);
		for (int i = 0; i < notches; i++) {
			screen.method_25401(at[0], at[1], 0.0, direction);
		}
	}

	private static int glfwKey(String name) {
		return switch (name) {
			case "left" -> GLFW.GLFW_KEY_LEFT;
			case "right" -> GLFW.GLFW_KEY_RIGHT;
			case "up" -> GLFW.GLFW_KEY_UP;
			case "down" -> GLFW.GLFW_KEY_DOWN;
			case "escape" -> GLFW.GLFW_KEY_ESCAPE;
			case "enter" -> GLFW.GLFW_KEY_ENTER;
			case "tab" -> GLFW.GLFW_KEY_TAB;
			case "space" -> GLFW.GLFW_KEY_SPACE;
			case "e" -> GLFW.GLFW_KEY_E;
			default -> throw new IllegalArgumentException("unknown key " + name);
		};
	}

	private void key(class_310 mc, CriticScenario.Step step) {
		class_437 screen = mc.field_1755;
		if (screen == null) {
			warn("key: no screen is open");
			return;
		}
		int code = glfwKey(step.text());
		int scancode = GLFW.glfwGetKeyScancode(code);
		int modifiers = step.shift() ? GLFW.GLFW_MOD_SHIFT : 0;
		JsonObject o = event("key");
		o.addProperty("key", step.text());
		o.addProperty("repeat", step.repeat());
		o.addProperty("shift", step.shift());
		emit(o);
		for (int i = 0; i < step.repeat() && mc.field_1755 == screen; i++) {
			screen.method_25404(code, scancode, modifiers);
			screen.method_16803(code, scancode, modifiers);
		}
	}

	private void click(class_437 screen, double x, double y) {
		JsonObject o = event("click");
		o.addProperty("x", round(x, 2));
		o.addProperty("y", round(y, 2));
		emit(o);
		screen.method_16014(x, y);
		screen.method_25402(x, y, 0);
		screen.method_25406(x, y, 0);
	}

	private static double dialX(class_437 screen, int khz) {
		int panelX = Math.max(0, (screen.field_22789 - RadioLayout.PANEL_W) / 2);
		return panelX + new DialGeometry(RadioLayout.DIAL_LEFT, RadioLayout.DIAL_WIDTH).centerX(khz);
	}

	private static double dialY(class_437 screen) {
		int panelY = Math.max(0, (screen.field_22790 - RadioLayout.PANEL_H) / 2);
		return panelY + RadioLayout.STRIP.y() + RadioLayout.STRIP.h() / 2.0;
	}

	private void clickDial(class_310 mc, int khz) {
		RadioScreen screen = radioScreen(mc, "click_dial_khz");
		if (screen != null) {
			click(screen, dialX(screen, khz), dialY(screen));
		}
	}

	private void dragDial(class_310 mc, int fromKhz, int toKhz) {
		RadioScreen screen = radioScreen(mc, "drag_dial_khz");
		if (screen == null) {
			return;
		}
		double y = dialY(screen);
		double fromX = dialX(screen, fromKhz);
		double toX = dialX(screen, toKhz);
		JsonObject o = event("drag");
		o.addProperty("from_khz", fromKhz);
		o.addProperty("to_khz", toKhz);
		emit(o);
		screen.method_16014(fromX, y);
		screen.method_25402(fromX, y, 0);
		int segments = 12;
		double last = fromX;
		for (int i = 1; i <= segments; i++) {
			double x = fromX + (toX - fromX) * i / segments;
			screen.method_25403(x, y, 0, x - last, 0.0);
			last = x;
		}
		screen.method_25406(toX, y, 0);
	}

	private void clickPower(class_310 mc) {
		RadioScreen screen = radioScreen(mc, "click_power");
		if (screen == null) {
			return;
		}
		for (class_364 child : screen.method_25396()) {
			if (child instanceof class_4185 button) {
				JsonObject o = event("click_power");
				o.addProperty("button", button.method_25369().getString());
				emit(o);
				click(screen, centreX(button), centreY(button));
				return;
			}
		}
		warn("click_power: the radio screen has no button");
	}

	private static double centreX(class_339 widget) {
		return widget.method_46426() + widget.method_25368() / 2.0;
	}

	private static double centreY(class_339 widget) {
		return widget.method_46427() + widget.method_25364() / 2.0;
	}

	private void mark(class_310 mc, CriticScenario.Step step) {
		if (markSound != null) {
			mc.method_1483().method_4870(markSound);
		}
		markSound = class_1109.method_4757(class_3414.method_47908(MARK_SOUND), 1.0f, MARK_VOLUME);
		markStopTick = tick + step.ticks();
		JsonObject o = event("mark");
		o.addProperty("label", step.text());
		o.addProperty("sound", MARK_SOUND.toString());
		o.addProperty("ticks", step.ticks());
		o.addProperty("note", "a 300 Hz tone, played non-positionally at volume " + MARK_VOLUME);
		emit(o);
		mc.method_1483().method_4873(markSound);
	}

	private void takeShot(class_310 mc, String name) {
		shotCount++;
		String file = String.format(Locale.ROOT, "%02d_%s.png", shotCount, name);
		Path target = shotsDir.resolve(file);
		JsonObject snapshot = snapshotJson(mc, "shot:" + name);
		try (class_1011 image = class_318.method_1663(mc.method_1522())) {
			image.method_4314(target);
			snapshot.addProperty("width", image.method_4307());
			snapshot.addProperty("height", image.method_4323());
		} catch (IOException | RuntimeException e) {
			warn("screenshot " + name + " failed: " + e);
		}
		snapshot.addProperty("type", "shot");
		snapshot.addProperty("name", name);
		snapshot.addProperty("file", outDir.relativize(target).toString());
		snapshot.addProperty("frames", frames);
		emit(snapshot);
	}

	// ------------------------------------------------------------------ shutting down

	private void beginQuit(class_310 mc, String reason) {
		if (quitRequested) {
			return;
		}
		quitRequested = true;
		JsonObject o = event("quit");
		o.addProperty("reason", reason);
		o.addProperty("steps_run", stepsRun);
		o.addProperty("shots", shotCount);
		o.addProperty("warnings", errorCount);
		o.addProperty("real_seconds", (System.currentTimeMillis() - startMillis) / 1000);
		emit(o);
		enter(Phase.QUITTING);
		// If leaving the world or stopping the game hangs, do not leave the run waiting for ever.
		Thread watchdog = new Thread(() -> {
			try {
				Thread.sleep(HALT_AFTER_SECONDS * 1000L);
			} catch (InterruptedException e) {
				return;
			}
			System.err.println("[fadoecravo critic] the game did not stop in " + HALT_AFTER_SECONDS + " s; halting");
			Runtime.getRuntime().halt(3);
		}, "critic-halt-watchdog");
		watchdog.setDaemon(true);
		watchdog.start();
		if (mc.field_1687 != null) {
			if (mc.field_1755 != null) {
				mc.method_1507(null); // lets an open radio screen send its last frequency
			}
			boolean singleplayer = mc.method_1542();
			mc.field_1687.method_8525();
			if (singleplayer) {
				mc.method_56134(new class_424(class_2561.method_43471("menu.savingLevel")));
			} else {
				mc.method_18099();
			}
			mc.method_1507(new class_442());
		}
	}

	private void tickQuitting(class_310 mc) {
		if (mc.field_1687 == null || tick - phaseStartTick > 100) {
			finish(mc);
		}
	}

	private void finish(class_310 mc) {
		enter(Phase.DONE);
		JsonObject o = event("end");
		o.addProperty("steps_run", stepsRun);
		o.addProperty("shots", shotCount);
		o.addProperty("warnings", errorCount);
		emit(o);
		log.close();
		copyScenarioIfMissing();
		mc.method_1592();
	}

	private void copyScenarioIfMissing() {
		try {
			Path copy = outDir.resolve("scenario.json");
			if (!Files.exists(copy)) {
				Files.copy(Paths.get(System.getProperty(PROPERTY_SCENARIO)), copy, StandardCopyOption.REPLACE_EXISTING);
			}
		} catch (IOException e) {
			LOGGER.warn("[critic] cannot copy the scenario", e);
		}
	}
}
