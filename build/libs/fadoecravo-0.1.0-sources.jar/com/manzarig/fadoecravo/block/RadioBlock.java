package com.manzarig.fadoecravo.block;

import com.manzarig.fadoecravo.RadioClientBridge;
import com.manzarig.fadoecravo.block.entity.RadioBlockEntity;
import com.manzarig.fadoecravo.registry.ModBlocks;
import com.manzarig.fadoecravo.registry.ModSounds;
import com.mojang.serialization.MapCodec;
import java.util.EnumMap;
import java.util.Map;
import net.minecraft.class_1269;
import net.minecraft.class_1657;
import net.minecraft.class_1750;
import net.minecraft.class_1922;
import net.minecraft.class_1937;
import net.minecraft.class_2237;
import net.minecraft.class_2248;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_2383;
import net.minecraft.class_2415;
import net.minecraft.class_2464;
import net.minecraft.class_2470;
import net.minecraft.class_2586;
import net.minecraft.class_265;
import net.minecraft.class_2680;
import net.minecraft.class_2689;
import net.minecraft.class_2741;
import net.minecraft.class_2746;
import net.minecraft.class_2753;
import net.minecraft.class_3419;
import net.minecraft.class_3726;
import net.minecraft.class_3965;
import net.minecraft.class_4970;

/**
 * The AM radio: a wooden cabinet with the dial on its front.
 *
 * <p>It has three states besides the facing. {@link #ON} says whether it is switched on and is what
 * the client listens to. {@link #POWERED} remembers whether a neighbour was giving it a redstone
 * signal, so that it can tell a new signal from one that was already there; it has no effect on
 * the model. Switching on or off happens in {@link #togglePower}, whether it is a sneaking player,
 * a screen or a redstone pulse that asks for it.
 *
 * <p>The frequency is not a block state: each of its 1071 values would multiply the number of block
 * states. It is in {@link RadioBlockEntity}.
 */
public class RadioBlock extends class_2237 {
	public static final MapCodec<RadioBlock> field_46280 = method_54094(RadioBlock::new);
	/** The side the front of the cabinet, with the dial, faces; that is towards the player who placed it. */
	public static final class_2753 FACING = class_2383.field_11177;
	public static final class_2746 ON = class_2746.method_11825("on");
	public static final class_2746 POWERED = class_2741.field_12484;

	/** The cabinet of a radio facing north: x 1-15 and z 4-12 pixels as seen from above, so 14 x 8, centred on the block. */
	private static final Footprint CABINET_FACING_NORTH = new Footprint(1, 4, 15, 12);
	/** The cabinet is 12 pixels high. */
	private static final double CABINET_HEIGHT = 12;
	/** The outline for each way the radio can face. Declared after the constants that {@link #cabinet} reads. */
	private static final Map<class_2350, class_265> SHAPES = new EnumMap<>(class_2350.class);

	static {
		for (class_2350 facing : class_2350.class_2353.field_11062) {
			SHAPES.put(facing, cabinet(facing));
		}
	}

	public RadioBlock(class_4970.class_2251 properties) {
		super(properties);
		method_9590(field_10647.method_11664()
				.method_11657(FACING, class_2350.field_11043)
				.method_11657(ON, false)
				.method_11657(POWERED, false));
	}

	private static class_265 cabinet(class_2350 facing) {
		Footprint footprint = CABINET_FACING_NORTH.turnedTo(facing);
		return class_2248.method_9541(footprint.minX(), 0, footprint.minZ(), footprint.maxX(), CABINET_HEIGHT, footprint.maxZ());
	}

	/**
	 * An area of the block seen from above, in pixels (a sixteenth of a block). It is a record of its
	 * own, apart from the block, so that the turning can be tested without a running game.
	 */
	record Footprint(double minX, double minZ, double maxX, double maxZ) {
		/**
		 * This footprint, which is the one of a radio facing north, turned about the centre of the
		 * block as far as a radio facing {@code facing} is turned: a quarter clockwise, seen from
		 * above, for each step from north to east to south to west, which is how the blockstate
		 * turns the model.
		 */
		Footprint turnedTo(class_2350 facing) {
			return switch (facing) {
				case field_11043 -> this;
				case field_11034 -> new Footprint(16 - maxZ, minX, 16 - minZ, maxX);
				case field_11035 -> new Footprint(16 - maxX, 16 - maxZ, 16 - minX, 16 - minZ);
				case field_11039 -> new Footprint(minZ, 16 - maxX, maxZ, 16 - minX);
				default -> throw new IllegalArgumentException("Not a horizontal direction: " + facing);
			};
		}
	}

	@Override
	protected MapCodec<? extends class_2237> method_53969() {
		return field_46280;
	}

	@Override
	protected void method_9515(class_2689.class_2690<class_2248, class_2680> builder) {
		builder.method_11667(FACING, ON, POWERED);
	}

	/**
	 * Faces the player and starts with {@link #POWERED} set to the signal that is already there, so
	 * that placing the radio next to a powered block does not count as a new signal.
	 */
	@Override
	public class_2680 method_9605(class_1750 context) {
		return method_9564()
				.method_11657(FACING, context.method_8042().method_10153())
				.method_11657(POWERED, context.method_8045().method_49803(context.method_8037()));
	}

	@Override
	protected class_265 method_9530(class_2680 state, class_1922 level, class_2338 pos, class_3726 context) {
		return SHAPES.get(state.method_11654(FACING));
	}

	/** {@link class_2237} makes its blocks invisible, expecting a block entity renderer. The radio uses a model. */
	@Override
	protected class_2464 method_9604(class_2680 state) {
		return class_2464.field_11458;
	}

	@Override
	protected class_2680 method_9598(class_2680 state, class_2470 rotation) {
		return state.method_11657(FACING, rotation.method_10503(state.method_11654(FACING)));
	}

	@Override
	protected class_2680 method_9569(class_2680 state, class_2415 mirror) {
		return state.method_26186(mirror.method_10345(state.method_11654(FACING)));
	}

	@Override
	public class_2586 method_10123(class_2338 pos, class_2680 state) {
		return new RadioBlockEntity(pos, state);
	}

	/**
	 * A plain use opens the radio screen, which exists on the client only; sneaking switches the
	 * radio on or off, which the server does. Both sides report success so that the click is
	 * consumed and the player's arm swings.
	 */
	@Override
	protected class_1269 method_55766(class_2680 state, class_1937 level, class_2338 pos, class_1657 player, class_3965 hit) {
		if (player.method_21823()) {
			if (!level.field_9236) {
				togglePower(level, pos, state);
			}
		} else if (level.field_9236) {
			RadioClientBridge.openScreen(pos);
		}
		return class_1269.method_29236(level.field_9236);
	}

	/**
	 * A redstone pulse switches the radio on or off, like a button on a note block. Only a signal
	 * that arrives counts, not one that goes away, and {@link #POWERED} is kept up to date either way.
	 */
	@Override
	protected void method_9612(class_2680 state, class_1937 level, class_2338 pos, class_2248 neighborBlock, class_2338 neighborPos, boolean movedByPiston) {
		if (level.field_9236) {
			return;
		}
		boolean powered = level.method_49803(pos);
		if (powered == state.method_11654(POWERED)) {
			return;
		}
		class_2680 updated = state.method_11657(POWERED, powered);
		if (powered) {
			togglePower(level, pos, updated);
		} else {
			level.method_8652(pos, updated, class_2248.field_31028);
		}
	}

	/**
	 * Flips {@link #ON} on the server and plays the sound of it: a click and the valves warming up
	 * when the radio is switched on, a click when it is switched off. The one place that does it,
	 * for sneaking, the screen and redstone.
	 *
	 * @param state the current state of the radio at {@code pos}; the new state is derived from it
	 */
	public static void togglePower(class_1937 level, class_2338 pos, class_2680 state) {
		if (level.field_9236 || !state.method_27852(ModBlocks.RADIO)) {
			return;
		}
		boolean switchOn = !state.method_11654(ON);
		level.method_8652(pos, state.method_11657(ON, switchOn), class_2248.field_31028);
		if (switchOn) {
			level.method_8396(null, pos, ModSounds.POWER_ON, class_3419.field_15245, 1.0f, 1.0f);
			level.method_8396(null, pos, ModSounds.TUBE_WARMUP, class_3419.field_15245, 1.0f, 1.0f);
		} else {
			level.method_8396(null, pos, ModSounds.POWER_OFF, class_3419.field_15245, 1.0f, 1.0f);
		}
	}
}
