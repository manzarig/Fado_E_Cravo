package com.manzarig.fadoecravo.block.entity;

import com.manzarig.fadoecravo.registry.ModBlockEntities;
import net.minecraft.class_2248;
import net.minecraft.class_2338;
import net.minecraft.class_2487;
import net.minecraft.class_2520;
import net.minecraft.class_2586;
import net.minecraft.class_2596;
import net.minecraft.class_2602;
import net.minecraft.class_2622;
import net.minecraft.class_2680;
import net.minecraft.class_7225;

/**
 * The state of one radio that is not part of its block state: the frequency its dial is set to.
 * Whether it is switched on lives in the block state ({@code RadioBlock.ON}).
 *
 * <p>The server owns the frequency. It changes it in response to a {@code SetFrequencyPayload} and
 * syncs it to nearby clients with the usual block entity update packet, which carries
 * {@link #method_16887}.
 */
public class RadioBlockEntity extends class_2586 {
	/** Lowest frequency of the medium wave band, in kHz. */
	public static final int MIN_KHZ = 530;
	/** Highest frequency of the medium wave band, in kHz. */
	public static final int MAX_KHZ = 1600;
	/** Frequency of a new radio, in kHz. It is the one of Rádio Tejo. */
	public static final int DEFAULT_KHZ = 1035;

	private static final String FREQUENCY_KEY = "frequency";

	private int frequencyKhz = DEFAULT_KHZ;

	public RadioBlockEntity(class_2338 pos, class_2680 state) {
		super(ModBlockEntities.RADIO, pos, state);
	}

	/** Brings a frequency into the band, so that a bad value in a save file or a packet cannot break the radio. */
	public static int clampKhz(int khz) {
		return Math.max(MIN_KHZ, Math.min(MAX_KHZ, khz));
	}

	/** Whether {@code khz} is inside the band; the server rejects a packet that is not. */
	public static boolean isValidKhz(int khz) {
		return khz >= MIN_KHZ && khz <= MAX_KHZ;
	}

	public int getFrequencyKhz() {
		return frequencyKhz;
	}

	/**
	 * Tunes the radio. The value is clamped to the band. If it changes, the chunk is saved and the
	 * tracking clients get the new frequency.
	 */
	public void setFrequencyKhz(int khz) {
		int clamped = clampKhz(khz);
		if (clamped == frequencyKhz) {
			return;
		}
		frequencyKhz = clamped;
		method_5431();
		if (field_11863 != null) {
			class_2680 state = method_11010();
			field_11863.method_8413(field_11867, state, state, class_2248.field_31036);
		}
	}

	@Override
	protected void method_11007(class_2487 tag, class_7225.class_7874 registries) {
		super.method_11007(tag, registries);
		tag.method_10569(FREQUENCY_KEY, frequencyKhz);
	}

	@Override
	protected void method_11014(class_2487 tag, class_7225.class_7874 registries) {
		super.method_11014(tag, registries);
		frequencyKhz = tag.method_10573(FREQUENCY_KEY, class_2520.field_33263) ? clampKhz(tag.method_10550(FREQUENCY_KEY)) : DEFAULT_KHZ;
	}

	/** What a client needs to know when the chunk is sent: the same as is saved. */
	@Override
	public class_2487 method_16887(class_7225.class_7874 registries) {
		return method_38244(registries);
	}

	@Override
	public class_2596<class_2602> method_38235() {
		return class_2622.method_38585(this);
	}
}
