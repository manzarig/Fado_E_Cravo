package com.manzarig.fadoecravo.datagen;

import com.manzarig.fadoecravo.registry.ModBlocks;
import java.util.concurrent.CompletableFuture;
import net.fabricmc.fabric.api.datagen.v1.FabricDataOutput;
import net.fabricmc.fabric.api.datagen.v1.provider.FabricBlockLootTableProvider;
import net.minecraft.class_7225;

/** Writes the loot tables of the mod's blocks. */
public class ModBlockLootTableProvider extends FabricBlockLootTableProvider {
	public ModBlockLootTableProvider(FabricDataOutput output, CompletableFuture<class_7225.class_7874> registries) {
		super(output, registries);
	}

	@Override
	public void method_10379() {
		method_46025(ModBlocks.RADIO);
	}
}
