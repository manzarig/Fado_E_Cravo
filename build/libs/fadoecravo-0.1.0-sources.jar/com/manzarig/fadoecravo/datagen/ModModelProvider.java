package com.manzarig.fadoecravo.datagen;

import com.manzarig.fadoecravo.FadoECravo;
import com.manzarig.fadoecravo.block.RadioBlock;
import com.manzarig.fadoecravo.registry.ModBlocks;
import net.fabricmc.fabric.api.datagen.v1.FabricDataOutput;
import net.fabricmc.fabric.api.datagen.v1.provider.FabricModelProvider;
import net.minecraft.class_2350;
import net.minecraft.class_2960;
import net.minecraft.class_4910;
import net.minecraft.class_4915;
import net.minecraft.class_4925;
import net.minecraft.class_4926;
import net.minecraft.class_4935;
import net.minecraft.class_4936;

/**
 * Writes the blockstate of the radio and the model of its item. The block models themselves,
 * {@code block/radio} and {@code block/radio_on}, are written by hand and only referred to here.
 */
public class ModModelProvider extends FabricModelProvider {
	private static final class_2960 RADIO_OFF_MODEL = FadoECravo.id("block/radio");
	private static final class_2960 RADIO_ON_MODEL = FadoECravo.id("block/radio_on");

	public ModModelProvider(FabricDataOutput output) {
		super(output);
	}

	@Override
	public void generateBlockStateModels(class_4910 generators) {
		// One variant for every combination of facing and on. POWERED is left out, so each variant
		// applies to both of its values: the model does not change with it.
		generators.field_22830.accept(class_4925.method_25769(ModBlocks.RADIO)
				.method_25775(class_4926.method_25784(RadioBlock.FACING, RadioBlock.ON)
						.method_25800((facing, on) -> class_4935.method_25824()
								.method_25828(class_4936.field_22887, on ? RADIO_ON_MODEL : RADIO_OFF_MODEL)
								.method_25828(class_4936.field_22886, rotationOf(facing)))));

		// The item looks like the radio that is switched off.
		generators.method_25623(ModBlocks.RADIO, RADIO_OFF_MODEL);
	}

	@Override
	public void generateItemModels(class_4915 generators) {
		// The radio is a block item, whose model is written with the block above.
	}

	/** The models have their front on the north face, so a radio facing east is turned 90 degrees clockwise, and so on. */
	private static class_4936.class_4937 rotationOf(class_2350 facing) {
		return switch (facing) {
			case field_11034 -> class_4936.class_4937.field_22891;
			case field_11035 -> class_4936.class_4937.field_22892;
			case field_11039 -> class_4936.class_4937.field_22893;
			default -> class_4936.class_4937.field_22890;
		};
	}
}
