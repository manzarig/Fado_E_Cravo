package com.manzarig.fadoecravo.datagen;

import com.manzarig.fadoecravo.registry.ModBlocks;
import java.util.concurrent.CompletableFuture;
import net.fabricmc.fabric.api.datagen.v1.FabricDataOutput;
import net.fabricmc.fabric.api.datagen.v1.provider.FabricTagProvider;
import net.minecraft.class_3481;
import net.minecraft.class_7225;

/** Writes the block tags the mod's blocks belong to. */
public class ModBlockTagProvider extends FabricTagProvider.BlockTagProvider {
	public ModBlockTagProvider(FabricDataOutput output, CompletableFuture<class_7225.class_7874> registries) {
		super(output, registries);
	}

	@Override
	protected void method_10514(class_7225.class_7874 registries) {
		getOrCreateTagBuilder(class_3481.field_33713).add(ModBlocks.RADIO);
	}
}
