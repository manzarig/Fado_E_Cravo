package com.manzarig.fadoecravo.datagen;

import com.manzarig.fadoecravo.registry.ModItems;
import java.util.concurrent.CompletableFuture;
import net.fabricmc.fabric.api.datagen.v1.FabricDataOutput;
import net.fabricmc.fabric.api.datagen.v1.provider.FabricRecipeProvider;
import net.minecraft.class_1802;
import net.minecraft.class_2447;
import net.minecraft.class_3489;
import net.minecraft.class_7225;
import net.minecraft.class_7800;
import net.minecraft.class_8790;

/** Writes the crafting recipes of the mod's items. */
public class ModRecipeProvider extends FabricRecipeProvider {
	public ModRecipeProvider(FabricDataOutput output, CompletableFuture<class_7225.class_7874> registries) {
		super(output, registries);
	}

	@Override
	public void method_10419(class_8790 output) {
		// Planks make the cabinet, a note block is the loudspeaker, copper is the wiring and redstone
		// stands in for the valves. The recipe appears in the recipe book once the player has a note block.
		class_2447.method_10437(class_7800.field_40642, ModItems.RADIO)
				.method_10439("PPP")
				.method_10439("PNP")
				.method_10439("CRC")
				.method_10433('P', class_3489.field_15537)
				.method_10434('N', class_1802.field_8643)
				.method_10434('C', class_1802.field_27022)
				.method_10434('R', class_1802.field_8725)
				.method_10429(method_32807(class_1802.field_8643), method_10426(class_1802.field_8643))
				.method_10431(output);
	}
}
