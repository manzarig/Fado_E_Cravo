package com.manzarig.fadoecravo.net;

import com.manzarig.fadoecravo.FadoECravo;
import net.minecraft.class_8710;
import net.minecraft.class_9129;
import net.minecraft.class_9135;
import net.minecraft.class_9139;

/**
 * Server to client: a breaking news bulletin is on the air on {@code stationId}, from the game time
 * {@code startGameTime}. {@code seed} lets every client choose the same clip from the station's
 * list. An empty station id means there is no bulletin, which is also how it is cleared.
 */
public record BreakingNewsPayload(String stationId, long startGameTime, long seed) implements class_8710 {
	public static final class_9154<BreakingNewsPayload> TYPE = new class_9154<>(FadoECravo.id("breaking_news"));
	public static final class_9139<class_9129, BreakingNewsPayload> CODEC = class_9139.method_56436(
			class_9135.field_48554, BreakingNewsPayload::stationId,
			class_9135.field_48551, BreakingNewsPayload::startGameTime,
			class_9135.field_48551, BreakingNewsPayload::seed,
			BreakingNewsPayload::new);

	/** There is no bulletin. */
	public static final BreakingNewsPayload CLEARED = new BreakingNewsPayload("", 0L, 0L);

	public boolean isCleared() {
		return stationId.isEmpty();
	}

	@Override
	public class_9154<? extends class_8710> method_56479() {
		return TYPE;
	}
}
