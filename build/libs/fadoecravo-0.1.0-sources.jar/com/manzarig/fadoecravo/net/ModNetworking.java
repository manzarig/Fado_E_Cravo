package com.manzarig.fadoecravo.net;

import com.manzarig.fadoecravo.block.RadioBlock;
import com.manzarig.fadoecravo.block.entity.RadioBlockEntity;
import com.manzarig.fadoecravo.broadcast.BreakingNewsState;
import java.util.Optional;
import net.fabricmc.fabric.api.networking.v1.PayloadTypeRegistry;
import net.fabricmc.fabric.api.networking.v1.ServerPlayConnectionEvents;
import net.fabricmc.fabric.api.networking.v1.ServerPlayNetworking;
import net.minecraft.class_1937;
import net.minecraft.class_2338;
import net.minecraft.class_2680;
import net.minecraft.class_3222;
import net.minecraft.server.MinecraftServer;

/**
 * Registers the mod's payloads and the server side of them.
 *
 * <p>Fabric runs a receiver on the server thread, so the handlers below read and change the world
 * directly. A client is not trusted: every request is checked against the player's reach, the loaded
 * chunks and the block that is actually at the position before it does anything.
 */
public final class ModNetworking {
	/** How far a player can be from a radio and still use it: 8 blocks, as a squared distance. */
	public static final double MAX_REACH_SQR = 64.0;

	private ModNetworking() {
	}

	public static void init() {
		PayloadTypeRegistry.playC2S().register(SetFrequencyPayload.TYPE, SetFrequencyPayload.CODEC);
		PayloadTypeRegistry.playC2S().register(TogglePowerPayload.TYPE, TogglePowerPayload.CODEC);
		PayloadTypeRegistry.playS2C().register(BreakingNewsPayload.TYPE, BreakingNewsPayload.CODEC);

		ServerPlayNetworking.registerGlobalReceiver(SetFrequencyPayload.TYPE,
				(payload, context) -> onSetFrequency(context.player(), payload));
		ServerPlayNetworking.registerGlobalReceiver(TogglePowerPayload.TYPE,
				(payload, context) -> onTogglePower(context.player(), payload));

		// A player who joins while a bulletin is on the air hears it too.
		ServerPlayConnectionEvents.JOIN.register((handler, sender, server) -> {
			BreakingNewsPayload current = BreakingNewsState.get(server).current();
			if (!current.isCleared()) {
				send(handler.method_32311(), current);
			}
		});
	}

	/** Sends the bulletin, or {@link BreakingNewsPayload#CLEARED}, to every player on the server. */
	public static void broadcast(MinecraftServer server, BreakingNewsPayload payload) {
		for (class_3222 player : server.method_3760().method_14571()) {
			send(player, payload);
		}
	}

	/** Skips a client that does not have the mod, which would not know the payload. */
	private static void send(class_3222 player, BreakingNewsPayload payload) {
		if (ServerPlayNetworking.canSend(player, BreakingNewsPayload.TYPE)) {
			ServerPlayNetworking.send(player, payload);
		}
	}

	private static void onSetFrequency(class_3222 player, SetFrequencyPayload payload) {
		if (!RadioBlockEntity.isValidKhz(payload.frequencyKhz())) {
			return;
		}
		reachableRadio(player, payload.pos()).ifPresent(radio -> radio.setFrequencyKhz(payload.frequencyKhz()));
	}

	private static void onTogglePower(class_3222 player, TogglePowerPayload payload) {
		reachableRadio(player, payload.pos()).ifPresent(radio -> {
			class_1937 level = player.method_37908();
			class_2680 state = level.method_8320(payload.pos());
			RadioBlock.togglePower(level, payload.pos(), state);
		});
	}

	/** Whether a player this far (squared) from the middle of a block may use it. */
	public static boolean isInReach(double distanceSqr) {
		return distanceSqr <= MAX_REACH_SQR;
	}

	/**
	 * The radio at {@code pos} if the player is close enough to it, in a loaded chunk, and the block
	 * there really is a radio. Cheapest checks first, because the position comes from the client.
	 */
	private static Optional<RadioBlockEntity> reachableRadio(class_3222 player, class_2338 pos) {
		double distanceSqr = player.method_5649(pos.method_10263() + 0.5, pos.method_10264() + 0.5, pos.method_10260() + 0.5);
		if (!isInReach(distanceSqr)) {
			return Optional.empty();
		}
		class_1937 level = player.method_37908();
		if (!level.method_8477(pos)) {
			return Optional.empty();
		}
		if (level.method_8321(pos) instanceof RadioBlockEntity radio) {
			return Optional.of(radio);
		}
		return Optional.empty();
	}
}
