package com.manzarig.fadoecravo.net;

import com.manzarig.fadoecravo.FadoECravo;
import net.minecraft.class_2338;
import net.minecraft.class_8710;
import net.minecraft.class_9129;
import net.minecraft.class_9139;

/**
 * Client to server: switch the radio at {@code pos} on or off, exactly as sneaking and using it
 * does. The server checks that the player is close to the radio.
 */
public record TogglePowerPayload(class_2338 pos) implements class_8710 {
	public static final class_9154<TogglePowerPayload> TYPE = new class_9154<>(FadoECravo.id("toggle_power"));
	public static final class_9139<class_9129, TogglePowerPayload> CODEC = class_9139.method_56434(
			class_2338.field_48404, TogglePowerPayload::pos,
			TogglePowerPayload::new);

	@Override
	public class_9154<? extends class_8710> method_56479() {
		return TYPE;
	}
}
