package com.manzarig.fadoecravo.net;

import com.manzarig.fadoecravo.FadoECravo;
import net.minecraft.class_2338;
import net.minecraft.class_8710;
import net.minecraft.class_9129;
import net.minecraft.class_9135;
import net.minecraft.class_9139;

/**
 * Client to server: tune the radio at {@code pos} to {@code frequencyKhz}. The server checks that
 * the player is close to the radio and that the frequency is inside the band before it obeys.
 */
public record SetFrequencyPayload(class_2338 pos, int frequencyKhz) implements class_8710 {
	public static final class_9154<SetFrequencyPayload> TYPE = new class_9154<>(FadoECravo.id("set_frequency"));
	public static final class_9139<class_9129, SetFrequencyPayload> CODEC = class_9139.method_56435(
			class_2338.field_48404, SetFrequencyPayload::pos,
			class_9135.field_48550, SetFrequencyPayload::frequencyKhz,
			SetFrequencyPayload::new);

	@Override
	public class_9154<? extends class_8710> method_56479() {
		return TYPE;
	}
}
