package com.manzarig.fadoecravo;

import com.manzarig.fadoecravo.command.RadioCommand;
import com.manzarig.fadoecravo.net.ModNetworking;
import com.manzarig.fadoecravo.registry.ModRegistry;

import net.fabricmc.api.ModInitializer;
import net.minecraft.class_2960;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class FadoECravo implements ModInitializer {
	public static final String MOD_ID = "fadoecravo";

	public static final Logger LOGGER = LoggerFactory.getLogger(MOD_ID);

	@Override
	public void onInitialize() {
		LOGGER.info("Fado e Cravo: the wireless is warming up.");
		ModRegistry.init();
		ModNetworking.init();
		RadioCommand.register();
	}

	public static class_2960 id(String path) {
		return class_2960.method_60655(MOD_ID, path);
	}
}
