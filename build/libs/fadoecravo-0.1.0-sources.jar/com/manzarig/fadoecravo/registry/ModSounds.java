package com.manzarig.fadoecravo.registry;

import com.manzarig.fadoecravo.FadoECravo;
import net.minecraft.class_2378;
import net.minecraft.class_2960;
import net.minecraft.class_3414;
import net.minecraft.class_7923;

/**
 * The sound effects of the radio, one {@link class_3414} for each {@code sfx.*} entry in
 * {@code sounds.json}. The station and music clips are not registered: the client plays them by
 * id through {@code RadioSoundInstance}.
 */
public final class ModSounds {
	/** Click when the radio is switched on. */
	public static final class_3414 POWER_ON = register("sfx.power_on");
	/** Click when the radio is switched off. */
	public static final class_3414 POWER_OFF = register("sfx.power_off");
	/** Valves heating up after the radio is switched on. */
	public static final class_3414 TUBE_WARMUP = register("sfx.tube_warmup");
	/** Heterodyne whistle when the dial passes over a station. */
	public static final class_3414 TUNING_WHISTLE = register("sfx.tuning_whistle");
	/** Seamless loop of static between stations. */
	public static final class_3414 STATIC_LOOP = register("sfx.static_loop");
	/** Seamless loop of the faint hiss of a carrier with no programme. */
	public static final class_3414 CARRIER_HISS = register("sfx.carrier_hiss");

	private ModSounds() {
	}

	private static class_3414 register(String path) {
		class_2960 id = FadoECravo.id(path);
		// A variable-range event takes its range from attenuation_distance in sounds.json.
		return class_2378.method_10230(class_7923.field_41172, id, class_3414.method_47908(id));
	}

	/** Loads the class, which registers the sounds. */
	static void init() {
	}
}
