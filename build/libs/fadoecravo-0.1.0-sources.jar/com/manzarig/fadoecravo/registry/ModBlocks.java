package com.manzarig.fadoecravo.registry;

import com.manzarig.fadoecravo.FadoECravo;
import com.manzarig.fadoecravo.block.RadioBlock;
import net.minecraft.class_2248;
import net.minecraft.class_2378;
import net.minecraft.class_2498;
import net.minecraft.class_2766;
import net.minecraft.class_3620;
import net.minecraft.class_4970;
import net.minecraft.class_7923;

/** The mod's blocks. */
public final class ModBlocks {
	/**
	 * A wooden cabinet that is not a full cube, so it must not occlude neighbouring faces. It is
	 * mined with an axe through the {@code minecraft:mineable/axe} tag and drops itself.
	 */
	public static final RadioBlock RADIO = register("radio", new RadioBlock(class_4970.class_2251.method_9637()
			.method_31710(class_3620.field_15996)
			.method_51368(class_2766.field_12651)
			.method_9626(class_2498.field_11547)
			.method_9632(2.0f)
			.method_22488()));

	private ModBlocks() {
	}

	private static <T extends class_2248> T register(String name, T block) {
		return class_2378.method_10230(class_7923.field_41175, FadoECravo.id(name), block);
	}

	/** Loads the class, which registers the blocks. */
	static void init() {
	}
}
