package com.manzarig.fadoecravo.registry;

import com.manzarig.fadoecravo.FadoECravo;
import net.minecraft.class_1747;
import net.minecraft.class_1792;
import net.minecraft.class_2378;
import net.minecraft.class_7923;

/** The mod's items. */
public final class ModItems {
	public static final class_1747 RADIO = register("radio", new class_1747(ModBlocks.RADIO, new class_1792.class_1793()));

	private ModItems() {
	}

	private static <T extends class_1792> T register(String name, T item) {
		return class_2378.method_10230(class_7923.field_41178, FadoECravo.id(name), item);
	}

	/** Loads the class, which registers the items. */
	static void init() {
	}
}
