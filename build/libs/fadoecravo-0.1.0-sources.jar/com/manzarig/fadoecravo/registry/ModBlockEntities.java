package com.manzarig.fadoecravo.registry;

import com.manzarig.fadoecravo.FadoECravo;
import com.manzarig.fadoecravo.block.entity.RadioBlockEntity;
import net.minecraft.class_2378;
import net.minecraft.class_2591;
import net.minecraft.class_7923;

/** The mod's block entity types. */
public final class ModBlockEntities {
	// The argument of build() is the data fixer type, which a mod without a datafixer passes as null.
	public static final class_2591<RadioBlockEntity> RADIO = class_2378.method_10230(
			class_7923.field_41181,
			FadoECravo.id("radio"),
			class_2591.class_2592.method_20528(RadioBlockEntity::new, ModBlocks.RADIO).method_11034(null));

	private ModBlockEntities() {
	}

	/** Loads the class, which registers the block entity types. */
	static void init() {
	}
}
