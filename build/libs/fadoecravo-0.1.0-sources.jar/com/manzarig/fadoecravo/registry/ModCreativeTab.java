package com.manzarig.fadoecravo.registry;

import com.manzarig.fadoecravo.FadoECravo;
import net.fabricmc.fabric.api.itemgroup.v1.FabricItemGroup;
import net.minecraft.class_1761;
import net.minecraft.class_1799;
import net.minecraft.class_2378;
import net.minecraft.class_2561;
import net.minecraft.class_7923;

/** The creative tab that holds the mod's items. */
public final class ModCreativeTab {
	public static final class_1761 TAB = class_2378.method_10230(
			class_7923.field_44687,
			FadoECravo.id("main"),
			FabricItemGroup.builder()
					.method_47321(class_2561.method_43471("itemGroup." + FadoECravo.MOD_ID))
					.method_47320(() -> new class_1799(ModItems.RADIO))
					.method_47317((parameters, output) -> output.method_45421(ModItems.RADIO))
					.method_47324());

	private ModCreativeTab() {
	}

	/** Loads the class, which registers the tab. */
	static void init() {
	}
}
